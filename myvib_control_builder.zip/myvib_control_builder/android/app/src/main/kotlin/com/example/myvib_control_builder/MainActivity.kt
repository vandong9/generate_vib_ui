package com.example.myvib_control_builder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
