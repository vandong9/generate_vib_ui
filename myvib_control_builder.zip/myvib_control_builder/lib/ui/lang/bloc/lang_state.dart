part of 'lang_bloc.dart';

@immutable
abstract class LangState extends Equatable {
  @override
  List<Object?> get props => [];
}

class LangInitial extends LangState {}

class LoadDataSuccess extends LangState {
  final List<MyLanguage>? listLangs;
  final MyLanguage? currentLang;

  LoadDataSuccess({this.currentLang, this.listLangs});

  LoadDataSuccess copyWith({
    MyLanguage? currentLang,
    List<MyLanguage>? listLangs,
  }) {
    return LoadDataSuccess(
      currentLang: currentLang ?? this.currentLang,
      listLangs: listLangs ?? this.listLangs,
    );
  }

  @override
  List<Object?> get props => [listLangs, currentLang];
}

class AppliedSuccess extends LangState {}
