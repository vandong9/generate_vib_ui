part of 'lang_bloc.dart';

@immutable
abstract class LangEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class LoadDataFromCache extends LangEvent {}

class FetchConfig extends LangEvent {}

class OnChangeLang extends LangEvent {
  final MyLanguage langSelected;

  OnChangeLang(this.langSelected);

  @override
  List<Object> get props => [];
}

class AttachCurrentLang extends LangEvent {
  final Locale locale;

  AttachCurrentLang(this.locale);

  @override
  List<Object> get props => [locale];
}

class AppliedNewLang extends LangEvent {}
