import 'package:after_layout/after_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';

import '../../common/constants/constants.dart';
import '../../common/di/injection/injector.dart';
import '../../common/dialog/progress_dialog.dart';
import '../../common/theme/theme.dart';
import '../../common/widget/base/base_widget.dart';
import '../../common/widget/buttons/my_button.dart';
import '../../common/widget/emptys/empty_widget.dart';
import '../../common/widget/loading/indicator_loading.dart';
import '../../common/widget/text/my_text_view.dart';
import '../../utils/navigate_util.dart';
import 'bloc/lang_bloc.dart';

class LangScreen extends BaseWidget {
  static const routeName = 'LangScreen';

  const LangScreen({key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return LangScreenState();
  }
}

class LangScreenState extends BaseState<LangScreen> with AfterLayoutMixin {
  final _langBloc = sl<LangBloc>();
  late ProgressDialog _pbLoading;

  @override
  void initState() {
    super.initState();
    //Call this method first when LoginScreen init
    initBasicInfo();
  }

  void initBasicInfo() {
    _langBloc.add(LoadDataFromCache());
    _langBloc.stream.listen((state) {
      if (_pbLoading.isShowing()) {
        _pbLoading.hide();
      }
      if (state is AppliedSuccess) {}
    });
  }

  @override
  void afterFirstLayout(BuildContext context) {
    _langBloc.add(AttachCurrentLang(context.locale));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    _pbLoading = ProgressDialog(context,
        showLogs: true,
        customBody: const NutsActivityIndicator(
          radius: sizeNormal,
          activeColor: Color(0xff383838),
          inactiveColor: Color(0xffDCBE76),
          startRatio: 0.55,
          animationDuration: Duration(milliseconds: 1000),
        ));
    _pbLoading.style(
      message: Lang.common_please_wait.tr(),
      elevation: 0,
      backgroundColor: Colors.transparent,
    );
    final theme = Theme.of(context);
    return BlocProvider(
      create: (_) => _langBloc,
      child: Container(
        color: theme.primaryColor,
        child: SafeArea(
          child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: const Color(0xff444444),
            appBar: AppBar(
              centerTitle: true,
              leading: IconButton(
                iconSize: sizeNormalx,
                icon: SvgPicture.asset(
                  Res.intro_image,
                ),
                onPressed: () {
                  NavigateUtil.pop(context);
                },
              ),
              elevation: 0,
              backgroundColor: theme.primaryColor,
              title: MyTextView(
                textStyle: textSmallxxx.copyWith(
                    color: Colors.white, fontWeight: FontWeight.w400),
                text: 'Ngôn Ngữ',
              ),
            ),
            body: LayoutBuilder(
              builder: (context, constraints) {
                return BlocBuilder<LangBloc, LangState>(
                    builder: (context, state) {
                  if (state is LoadDataSuccess) {
                    return Column(
                      children: [
                        Expanded(
                          child: ListView.separated(
                            shrinkWrap: true,
                            itemCount: state.listLangs?.length ?? 0,
                            itemBuilder: (BuildContext context, int index) {
                              final langModel = state.listLangs![index];
                              return Material(
                                color: const Color(0xff565656),
                                child: InkWell(
                                  onTap: () {
                                    _langBloc.add(OnChangeLang(langModel));
                                  },
                                  child: Container(
                                    constraints: const BoxConstraints(
                                        minHeight: sizeLargexxx),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: sizeNormal,
                                      vertical: sizeSmallxx,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        MyTextView(
                                          text: langModel.name,
                                          textStyle: textSmallxxx.copyWith(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        if (state.currentLang == langModel)
                                          const Icon(
                                            Icons.check,
                                            size: sizeNormalxx,
                                            color: Color(0xffF5D484),
                                          )
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                            separatorBuilder:
                                (BuildContext context, int index) {
                              return const Divider(
                                color: Color(0xff444444),
                                height: 1,
                              );
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(sizeNormal),
                          child: MyButton(
                            text: 'Thay đổi',
                            isFillParent: false,
                            paddingVertical: 0,
                            height: sizeLarge,
                            paddingHorizontal: sizeNormal,
                            onTap: () async {
                              await _pbLoading.show();
                              changeLang(state.currentLang);
                              await Future.delayed(const Duration(seconds: 1));
                              _langBloc.add(AppliedNewLang());
                            },
                            textStyle: textSmallxxx.copyWith(
                              color: const Color(0xff383838),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    );
                  }
                  return const EmptyState();
                });
              },
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _langBloc.close();
    super.dispose();
  }
}
