import 'package:after_layout/after_layout.dart';
import 'package:floralpunk/common/widget/buttons/my_button.dart';
import 'package:floralpunk/utils/navigate_util.dart';
import 'package:floralpunk/utils/ui_util.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/services.dart';
import '../../common/constants/constants.dart';
import '../../common/di/injection/injector.dart';
import '../../common/theme/theme.dart';
import '../../common/widget/base/base_widget.dart';
import '../login/login_page.dart';
import 'bloc/intro_bloc.dart';

class IntroScreen extends BaseWidget {
  static const routeName = '/IntroScreen';

  const IntroScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return IntroScreenState();
  }
}

class IntroScreenState extends BaseState<IntroScreen>
    with TickerProviderStateMixin, AfterLayoutMixin {
  final IntroBloc _introBloc = sl<IntroBloc>();
  late Animation _LogoAnimation;
  late AnimationController _LogoAnimationController;

  @override
  void initState() {
    super.initState();
    //Call this method first when LoginScreen init
    initBasicInfo();
  }

  void initBasicInfo() {
    _LogoAnimationController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 15000));
    _LogoAnimation = Tween<double>(begin: 1, end: 1.2).animate(
        CurvedAnimation(curve: Curves.ease, parent: _LogoAnimationController));

    _LogoAnimationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _LogoAnimationController.reverse();
      } else if (status == AnimationStatus.dismissed) {
        _LogoAnimationController.forward();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return WillPopScope(
      onWillPop: () => Future(() => false),
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: Stack(
          fit: StackFit.expand,
          children: [
            AnimatedBuilder(
                animation: _LogoAnimationController,
                builder: (context, child) {
                  final value = _LogoAnimation.value;
                  return Transform.scale(
                    scale: value,
                    child: UIUtil.makeImageWidget(
                      Res.intro_image,
                      boxFit: BoxFit.cover,
                    ),
                  );
                }),
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.all(
                  sizeSmallxxx,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FittedBox(
                      alignment: Alignment.center,
                      fit: BoxFit.scaleDown,
                      child: Text(
                        Lang.splash_floral_punk.tr(),
                        style: textExLarge.copyWith(
                          color: ThemeColor.whiteColor,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    FittedBox(
                      alignment: Alignment.center,
                      fit: BoxFit.scaleDown,
                      child: Text(
                        Lang.splash_minimal_with_a_premium.tr(),
                        maxLines: 2,
                        style: textLarge.copyWith(
                          fontStyle: FontStyle.italic,
                          color: ThemeColor.whiteColor,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: sizeNormalxxx,
                    ),
                    Center(
                      child: Column(
                        children: [
                          MyButton(
                            text: Lang.splash_become_a_member.tr(),
                            radius: 0,
                            isFillParent: true,
                            textStyle: textNormal.copyWith(
                              color: ThemeColor.blackFont,
                              fontWeight: FontWeight.w300,
                              fontFamily: MyFontFamily.Helvetica,
                            ),
                            onTap: () {
                              NavigateUtil.openPage(
                                context,
                                LoginScreen.routeName,
                              );
                            },
                          ),
                          const SizedBox(
                            height: sizeNormal,
                          ),
                          Container(
                            padding: const EdgeInsets.only(
                              bottom: sizeIcon,
                            ),
                            decoration: const BoxDecoration(
                                border: Border(
                                    bottom: BorderSide(
                              color: ThemeColor.whiteColor,
                              width: 1,
                            ))),
                            child: Text(
                              Lang.splash_explore_more.tr(),
                              style: textNormalxx.copyWith(
                                color: ThemeColor.whiteColor,
                                fontFamily: MyFontFamily.Helvetica,
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: sizeNormalxx,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _introBloc.close();
    _LogoAnimationController.dispose();
    super.dispose();
  }

  @override
  void afterFirstLayout(BuildContext context) {
    _LogoAnimationController.forward();
  }
}
