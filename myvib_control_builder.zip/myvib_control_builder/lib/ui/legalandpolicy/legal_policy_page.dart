import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../../common/di/injection/injector.dart';
import '../../common/widget/base/base_widget.dart';
import '../../common/widget/headers/header_short.dart';
import '../../common/widget/loading/circle_loading.dart';
import '../../utils/navigate_util.dart';
import 'bloc/legal_policy_bloc.dart';

class LegalPolicyPage extends BaseWidget {
  static const routeName = 'LegalPolicyPage';
  final Map? data;

  LegalPolicyPage({this.data});

  @override
  State<StatefulWidget> createState() {
    return LegalPolicyPageState();
  }
}

class LegalPolicyPageState extends BaseState<LegalPolicyPage> {
  final LegalPolicyBloc _legalPolicyBloc = sl<LegalPolicyBloc>();
  late String title;

  late String url;
  bool isLoading = true;
  bool isShowWeb = false;
  InAppWebViewGroupOptions options = InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: false,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
      ));

  @override
  void initState() {
    super.initState();
    if (widget.data != null) {
      if (widget.data?.containsKey('title') ?? false) {
        title = widget.data!['title'];
      } else {
        title = '';
      }
      if (widget.data?.containsKey('url') ?? false) {
        url = widget.data!['url'];
      } else {
        url = '';
      }
    } else {
      title = '';
      url = '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Scaffold(
            backgroundColor: const Color(0xffFDFBF5),
            body: Column(
              children: [
                HeaderShort(
                  onClickBack: () {
                    NavigateUtil.pop(context);
                  },
                  title: title,
                ),
                Expanded(
                    child: Stack(
                  children: [
                    Opacity(
                      opacity: isShowWeb ? 1 : 0,
                      child: InAppWebView(
                        initialUrlRequest: URLRequest(url: Uri.parse(url)),
                        initialOptions: options,
                        onLoadStop: (controller, url) {
                          setState(() {
                            isLoading = false;
                            isShowWeb = true;
                          });
                        },
                        onLoadStart: (controller, url) {},
                      ),
                    ),
                    if (isLoading) CircleLoading(),
                  ],
                )),
              ],
            ));
      },
    );
  }

  @override
  void dispose() {
    _legalPolicyBloc.close();
    super.dispose();
  }
}
