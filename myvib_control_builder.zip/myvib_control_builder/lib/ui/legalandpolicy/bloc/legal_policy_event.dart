import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class LegalPolicyEvent extends Equatable {
  const LegalPolicyEvent();

  @override
  List<Object> get props => [];
}