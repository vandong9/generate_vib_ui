import 'dart:convert';
import 'dart:developer' as MyLog;
import 'package:after_layout/after_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../../common/di/injection/injector.dart';
import '../../common/theme/theme.dart';
import '../../common/widget/base/base_widget.dart';
import '../../common/widget/base/bloc/base_bloc.dart';
import '../../common/widget/buttons/my_button.dart';
import 'bloc/home_bloc.dart';

class HomeScreen extends BaseWidget {
  static const routeName = '/HomeScreen';

  const HomeScreen();

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return HomeScreenState();
  }
}

class HomeScreenState extends BaseState<HomeScreen> with AfterLayoutMixin {
  final HomeBloc _homeBloc = sl<HomeBloc>();

  @override
  void initState() {
    super.initState();
    //Call this method first when LoginScreen init
    initBasicInfo();
  }

  void initBasicInfo() async {
    _homeBloc.add(LoadItemList());
    _homeBloc.stream.listen((state) {});
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return WillPopScope(
      onWillPop: () => Future(() => false),
      child: Scaffold(
        backgroundColor: ThemeColor.whiteColor,
        body: SafeArea(
          child: LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: double.infinity,
                  alignment: Alignment.center,
                  child: const Text(
                    'Home screen',
                    style: textNormal,
                  ),
                ),
                MyButton(
                  text: 'Sigout',
                  textAlign: TextAlign.center,
                  textStyle: textNormal,
                  onTap: () {
                    sl<BaseBloc>().add(Logout());
                  },
                ),
              ],
            );
          }),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _homeBloc.close();
    super.dispose();
  }

  @override
  void afterFirstLayout(BuildContext context) {}
}
