import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../data/model/item_model.dart';
import '../../../data/repository/config_repository.dart';
import '../../../data/source/failure.dart';

part 'home_event.dart';

part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final ConfigRepository configRepository;

  HomeBloc({
    required this.configRepository,
  }) : super(HomeInitial()) {
    on<HomeEvent>((event, emit) async {
      if (event is LoadItemList) {
        final result = configRepository.getItemList();
        if (result != null) {
          emit.call(LoadDataSuccess(itemList: result));
        }
      } else if (event is FetchItemList) {
        final result = await configRepository.fetchItems();
        emit.call(result.fold((l) {
          if (l is RemoteDataFailure) {
            print('l.errorMessage');
            print(l.errorMessage);
          }
          final currentState = state;
          if (currentState is LoadDataSuccess) {
            return currentState.copyWith(
                timeRefresh: DateTime.now().millisecondsSinceEpoch.toString());
          } else {
            return currentState;
          }
        },
            (r) => LoadDataSuccess(
                  itemList: r,
                  timeRefresh: DateTime.now().millisecondsSinceEpoch.toString(),
                )));
      }
    });
  }
}
