part of 'register_bloc.dart';

@immutable
abstract class RegisterState {}

class RegisterInitial extends RegisterState {
  final RegisterView registerView;
  final DateTime? dob;

  RegisterInitial({
    this.registerView = RegisterView.viewForm,
    this.dob,
  });

  @override
  List<Object?> get props => [
        registerView,
        dob,
      ];
}

class RegisterSuccess extends RegisterState {
  final FloralPunk.UserInfo userInfo;

  RegisterSuccess({
    required this.userInfo,
  });

  @override
  List<Object?> get props => [
        userInfo,
      ];
}

class RegisterFail extends RegisterState {
  final String message;

  RegisterFail({
    required this.message,
  });

  @override
  List<Object?> get props => [
        message,
      ];
}

enum RegisterView { viewForm, viewOTP }
