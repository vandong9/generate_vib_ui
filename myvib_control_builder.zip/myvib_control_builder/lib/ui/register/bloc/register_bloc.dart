import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

import '../../../common/di/injection/injector.dart';
import '../../../common/widget/base/bloc/base_bloc.dart';
import '../../../data/model/user_info.dart' as FloralPunk;
import '../../../data/repository/user_repository.dart';
import '../../../data/source/failure.dart';

part 'register_event.dart';

part 'register_state.dart';

class RegisterBloc extends Bloc<RegisterEvent, RegisterState> {
  final UserRepository userRepository;

  RegisterBloc({
    required this.userRepository,
  }) : super(RegisterInitial()) {
    on<RegisterEvent>((event, emit) async {
      if (event is OnDobChange) {
        final currentState = state;
        if (currentState is RegisterInitial) {
          emit.call(
            RegisterInitial(
              registerView: currentState.registerView,
              dob: event.dob,
            ),
          );
        }
      } else if (event is OnBack) {
        final currentState = state;
        if (currentState is RegisterInitial) {
          emit.call(
            RegisterInitial(
              registerView: RegisterView.viewForm,
              dob: currentState.dob,
            ),
          );
        } else {
          emit.call(
            RegisterInitial(
              registerView: RegisterView.viewForm,
            ),
          );
        }
      } else if (event is DoVerifyOtp) {
        final currentState = state;
        if (currentState is RegisterInitial) {
          emit.call(
            RegisterInitial(
              registerView: RegisterView.viewOTP,
              dob: currentState.dob,
            ),
          );
        }
      } else if (event is DoRegis) {
        final result = await userRepository.login(
            fullName: event.userName,
            phoneNumber: event.phoneNumber,
            firebaseToken: event.firebaseToken,
            provider: event.provider,
            dob: event.dob.toIso8601String());
        emit.call(result.fold(
            (l) => RegisterFail(message: (l as RemoteDataFailure).errorMessage),
            (r) {
          sl<BaseBloc>().add(Init());
          return RegisterSuccess(
            userInfo: r,
          );
        }));
      }
    });
  }
}
