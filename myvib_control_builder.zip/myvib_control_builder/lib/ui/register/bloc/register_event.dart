part of 'register_bloc.dart';

@immutable
abstract class RegisterEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class OnBack extends RegisterEvent {}

class OnDobChange extends RegisterEvent {
  final DateTime dob;

  OnDobChange({
    required this.dob,
  });

  @override
  List<Object?> get props => [
        dob,
      ];
}

class DoVerifyOtp extends RegisterEvent {
  final String phoneNumber;

  DoVerifyOtp({
    required this.phoneNumber,
  });

  @override
  List<Object?> get props => [
        phoneNumber,
      ];
}

class ResendOtp extends RegisterEvent {
  final String phoneNumber;

  ResendOtp({
    required this.phoneNumber,
  });

  @override
  List<Object?> get props => [
        phoneNumber,
      ];
}

class DoRegis extends RegisterEvent {
  final String userName;
  final String phoneNumber;
  final String firebaseToken;
  final String provider;
  final DateTime dob;
  final UserCredential userCredential;

  DoRegis({
    required this.userName,
    required this.phoneNumber,
    required this.dob,
    required this.firebaseToken,
    required this.userCredential,
    required this.provider,
  });

  @override
  List<Object?> get props => [
        userName,
        phoneNumber,
        firebaseToken,
        dob,
        provider,
        userCredential,
      ];
}
