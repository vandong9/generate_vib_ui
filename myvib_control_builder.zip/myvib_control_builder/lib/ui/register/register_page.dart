import 'package:firebase_phone_auth_handler/firebase_phone_auth_handler.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import '../../common/constants/constants.dart';
import '../../common/di/injection/injector.dart';
import '../../common/dialog/notify_dialog.dart';
import '../../common/theme/theme.dart';
import '../../common/widget/base/base_widget.dart';
import '../../common/widget/buttons/my_button.dart';
import '../../common/widget/inputtexts/my_input_field.dart';
import '../../common/widget/inputtexts/otp_input.dart';
import '../../common/widget/resend_widget.dart';
import '../../utils/date_util.dart';
import '../../utils/navigate_util.dart';
import '../../utils/ui_util.dart';
import '../home/home_page.dart';
import 'bloc/register_bloc.dart';

class RegisterScreen extends BaseWidget {
  static const routeName = '/RegisterScreen';
  final Map data;

  const RegisterScreen({
    Key? key,
    required this.data,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return RegisterScreenState();
  }
}

class RegisterScreenState extends BaseState<RegisterScreen> {
  // FirebaseAuth auth = FirebaseAuth.instance;
  final _formKey = GlobalKey<FormState>();
  final _resendWidgetKey = GlobalKey<ResendWidgetState>();

  final _focusFullName = FocusNode();
  final _focusPhone = FocusNode();

  final mobileController = TextEditingController();

  final nameController = TextEditingController();

  final RegisterBloc _registerBloc = sl<RegisterBloc>();

  var verificationId = '';

  DateTime? dob;

  final listOtpFields =
      List<TextEditingController>.generate(6, (c) => TextEditingController())
          .toList();
  final listOtpFocusFields =
      List<FocusNode>.generate(6, (c) => FocusNode()).toList();

  @override
  void initState() {
    super.initState();
    //Call this method first when LoginScreen init
    initBasicInfo();
  }

  void initBasicInfo() {
    _registerBloc.stream.listen((state) {
      if (pbLoading?.isShowing() ?? false) {
        pbLoading?.hide();
      }

      if (state is RegisterFail) {
        UIUtil.showDialogOrigin(
          child: NotifyDialog(
            content: state.message,
            textButton: Lang.common_close.tr(),
          ),
          context: context,
        ).then((value) {
          for (var f in listOtpFields) {
            f.clear();
          }
          _registerBloc.add(OnBack());
        });
      }

      if (state is RegisterSuccess) {
        NavigateUtil.openPage(context, HomeScreen.routeName);
      }
    });
    listOtpFocusFields.asMap().entries.forEach((node) {
      node.value.addListener(() {
        if (node.value.hasFocus && node.key > 0) {
          if (listOtpFields[node.key - 1].text.isEmpty) {
            listOtpFocusFields[node.key - 1].requestFocus();
          }
        }
      });
    });

    //check has Social Data
    if (widget.data.containsKey('fullName')) {
      nameController.text = widget.data['fullName'];
    }
    if (widget.data.containsKey('phoneNumber')) {
      mobileController.text = widget.data['phoneNumber'];
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    final otpFieldWidth = size.width / 6 - sizeVerySmall * 4;

    initDialogLoading(context);
    super.build(context);
    return WillPopScope(
      onWillPop: () => Future(() => false),
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark,
        child: GestureDetector(
          onTap: () {
            FocusScopeNode currentFocus = FocusScope.of(context);
            if (!currentFocus.hasPrimaryFocus) {
              currentFocus.unfocus();
            }
          },
          child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: AppBar(
              title: Text(Lang.register_become_a_member.tr()),
              titleTextStyle: textNormal.copyWith(
                color: ThemeColor.blackColor,
                fontWeight: FontWeight.w300,
              ),
              leading: IconButton(
                icon: SvgPicture.asset(
                  Res.ic_arrow_back,
                  color: Colors.black,
                ),
                onPressed: handleBackPressed,
              ),
              titleSpacing: 0,
              backgroundColor: ThemeColor.whiteColor,
              shadowColor: ThemeColor.transparent,
              bottom: PreferredSize(
                child: Container(
                  color: Colors.black,
                  height: 1.0,
                ),
                preferredSize: const Size.fromHeight(1),
              ),
            ),
            body: BlocProvider(
              create: (_) => _registerBloc,
              child: Form(
                key: _formKey,
                child: BlocBuilder<RegisterBloc, RegisterState>(
                  builder: (context, state) {
                    var currentView = RegisterView.viewForm;
                    DateTime? currentDob = dob;
                    if (state is RegisterInitial) {
                      currentView = state.registerView;
                      currentDob = state.dob ?? currentDob;
                    }
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Container(
                          margin: const EdgeInsets.symmetric(
                            horizontal: sizeNormal,
                            vertical: sizeSmall,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              MyInputField(
                                focusNode: _focusFullName,
                                textHint: Lang.register_full_name.tr(),
                                textStyle: textNormalx.copyWith(
                                  fontFamily: MyFontFamily.Helvetica,
                                  fontWeight: FontWeight.w300,
                                ),
                                usePhoneFormat: false,
                                horizontalPadding: sizeSmall,
                                isEnable: currentView != RegisterView.viewOTP,
                                autoValidateMode:
                                    AutovalidateMode.onUserInteraction,
                                keyboardType: TextInputType.name,
                                textController: nameController,
                                textCapitalization: TextCapitalization.words,
                                onFieldSubmitted: (v) {
                                  FocusScope.of(context).unfocus();
                                },
                              ),
                              const SizedBox(
                                height: sizeNormal,
                              ),
                              GestureDetector(
                                onTap: () {
                                  if (currentView == RegisterView.viewOTP) {
                                    return;
                                  }
                                  dobHandler();
                                },
                                child: Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.only(
                                    bottom: sizeSmall,
                                    top: sizeSmall,
                                    left: sizeSmall,
                                  ),
                                  decoration: const BoxDecoration(
                                      border: Border(
                                          bottom: BorderSide(
                                    color: ThemeColor.blackColor,
                                    width: 1,
                                  ))),
                                  child: Text(
                                    currentDob != null
                                        ? DateUtil.convertTimeStampToTime(
                                            currentDob.millisecondsSinceEpoch,
                                            format:
                                                DateUtil.DATE_FORMAT_DDMMYYYY,
                                          )
                                        : Lang.register_birthday.tr(),
                                    style: textNormalx.copyWith(
                                      color: currentDob != null
                                          ? ThemeColor.blackColor
                                          : ThemeColor.placeHolderTextColor,
                                      fontFamily: MyFontFamily.Helvetica,
                                      fontWeight: FontWeight.w300,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: sizeNormal,
                              ),
                              MyInputField(
                                focusNode: _focusPhone,
                                textHint: Lang.register_phone_number.tr(),
                                textStyle: textNormalx.copyWith(
                                  fontFamily: MyFontFamily.Helvetica,
                                  fontWeight: FontWeight.w300,
                                ),
                                usePhoneFormat: false,
                                horizontalPadding: sizeSmall,
                                isEnable: currentView != RegisterView.viewOTP,
                                maxLen: 13,
                                autoValidateMode:
                                    AutovalidateMode.onUserInteraction,
                                keyboardType: TextInputType.phone,
                                textController: mobileController,
                                textCapitalization:
                                    TextCapitalization.sentences,
                                onFieldSubmitted: (v) {
                                  FocusScope.of(context).unfocus();
                                },
                              ),
                              const SizedBox(
                                height: sizeSmall,
                              ),
                              if (currentView == RegisterView.viewOTP)
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: sizeSmall,
                                        horizontal: sizeSmall,
                                      ),
                                      child: Text(
                                        Lang.register_confirm_otp.tr(),
                                        textAlign: TextAlign.center,
                                        style: textSmallxxx.copyWith(
                                          color: ThemeColor.blackColor,
                                          fontFamily: MyFontFamily.Helvetica,
                                          fontWeight: FontWeight.w300,
                                        ),
                                      ),
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: listOtpFields
                                          .asMap()
                                          .entries
                                          .map((e) {
                                        return OtpInput(
                                          e.value,
                                          e.key == 0,
                                          focusNode: listOtpFocusFields[e.key],
                                          nextFocusNode: (e.key <
                                                  listOtpFields.length - 1)
                                              ? listOtpFocusFields[e.key + 1]
                                              : null,
                                          previousFocusNode: (e.key > 0)
                                              ? listOtpFocusFields[e.key - 1]
                                              : null,
                                          submitOtp: (e.key == 5)
                                              ? () {
                                                  print("submit otp");
                                                }
                                              : null,
                                          height: sizeExLargexx,
                                          width: otpFieldWidth,
                                        );
                                      }).toList(),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),
                        if (currentView != RegisterView.viewOTP)
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: sizeNormal,
                              vertical: sizeSmall,
                            ),
                            child: Column(
                              children: [
                                MyButton(
                                  text: Lang.register_become_a_member.tr(),
                                  radius: 0,
                                  isFillParent: true,
                                  buttonStyle: styleButtonColor_2,
                                  textStyle: textNormal.copyWith(
                                    color: ThemeColor.blackFont,
                                    fontFamily: MyFontFamily.Helvetica,
                                    fontWeight: FontWeight.w300,
                                  ),
                                  onTap: doVerifyOtp,
                                ),
                                const SizedBox(
                                  height: sizeNormal,
                                ),
                                Text(
                                  Lang.register_we_will_send_an_otp_code_to
                                      .tr(),
                                  textAlign: TextAlign.center,
                                  style: textSmallxx.copyWith(
                                    color: ThemeColor.blackColor,
                                    fontFamily: MyFontFamily.Helvetica,
                                    fontWeight: FontWeight.w300,
                                  ),
                                )
                              ],
                            ),
                          ),
                        if (currentView == RegisterView.viewOTP)
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: sizeNormal,
                              vertical: sizeSmall,
                            ),
                            child: Column(
                              children: [
                                MyButton(
                                  text: Lang.register_confirm_otp.tr(),
                                  radius: 0,
                                  isFillParent: true,
                                  buttonStyle: styleButtonColor_2,
                                  textStyle: textNormal.copyWith(
                                    color: ThemeColor.blackFont,
                                    fontFamily: MyFontFamily.Helvetica,
                                    fontWeight: FontWeight.w300,
                                  ),
                                  onTap: sendCode,
                                ),
                                const SizedBox(
                                  height: sizeNormal,
                                ),
                                ResendWidget(
                                  key: _resendWidgetKey,
                                  onResend: () {
                                    firebaseVerifyOtp(
                                      phoneNumber: mobileController.text,
                                    );
                                  },
                                ),
                              ],
                            ),
                          )
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void dobHandler() {
    showDatePicker(
      context: context,
      initialDate: dob ?? DateTime.now(),
      firstDate: DateTime(1950),
      lastDate: DateTime(2025),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.black,
              // header background color
              onPrimary: Colors.white,
              // header text color
              onSurface: Colors.black, // body text color
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                primary: Colors.black, // button text color
              ),
            ),
          ),
          child: child!,
        );
      },
    ).then((value) {
      if (value != null) {
        dob = value;
        _registerBloc.add(OnDobChange(
          dob: value,
        ));
      }
    });
  }

  void doVerifyOtp() async {
    var errorMessage = '';

    if (mobileController.text.isEmpty || mobileController.text.length < 10) {
      errorMessage = Lang.common_please_correct_phone_number.tr();
    }
    if (dob == null) {
      errorMessage = Lang.common_please_correct_dob.tr();
    }
    if (nameController.text.isEmpty) {
      errorMessage = Lang.common_please_enter_full_name.tr();
    }
    if (errorMessage.isNotEmpty) {
      showErrorMessage(errorMessage);
      return;
    }
    _registerBloc.add(
      DoVerifyOtp(
        phoneNumber: mobileController.text,
      ),
    );
    await Future.delayed(
      const Duration(milliseconds: 300),
    );
    firebaseVerifyOtp(phoneNumber: mobileController.text);
  }

  void sendCode() async {
    if (!(pbLoading?.isShowing() ?? false)) {
      pbLoading?.show();
    }
    final smsCode = listOtpFields.map((e) => e.text).toList().join('');
    // Create a PhoneAuthCredential with the code
    PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId, smsCode: smsCode);

    // Sign the user in (or link) with the credential
    final userCredential = await auth.signInWithCredential(credential);
    doRegister(userCredential: userCredential);
  }

  void firebaseVerifyOtp({
    required String phoneNumber,
  }) async {
    pbLoading?.show();
    _resendWidgetKey.currentState?.startTimer();
    auth.verifyPhoneNumber(
      phoneNumber: '+84${phoneNumber.replaceAll('+84', '')}',
      verificationCompleted: (PhoneAuthCredential credential) async {
        if (!(pbLoading?.isShowing() ?? false)) {
          pbLoading?.show();
        }
        final userCredential = await auth.signInWithCredential(credential);
        doRegister(userCredential: userCredential);
      },
      verificationFailed: (FirebaseAuthException e) {
        pbLoading?.hide();
        showErrorMessage(e.message ?? 'verificationFailed');
      },
      codeSent: (String verificationId, int? resendToken) {
        pbLoading?.hide();
        this.verificationId = verificationId;
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        pbLoading?.hide();
        // showErrorMessage('AutoRetrievalTimeout');
      },
    );
  }

  void handleBackPressed() {
    final currentState = _registerBloc.state;
    if (currentState is RegisterInitial) {
      if (currentState.registerView == RegisterView.viewOTP) {
        _registerBloc.add(OnBack());
      } else {
        Navigator.of(context).pop();
      }
    } else {
      Navigator.of(context).pop();
    }
  }

  void doRegister({
    required UserCredential userCredential,
  }) async {
    var token = await userCredential.user?.getIdToken();
    if (widget.data.containsKey('firebaseToken')) {
      token = widget.data['firebaseToken'];
    }
    _registerBloc.add(
      DoRegis(
        userName: userCredential.user?.displayName ?? '',
        phoneNumber: mobileController.text.replaceAll('+84', '').trim(),
        firebaseToken: token ?? '',
        userCredential: userCredential,
        provider: 'Firebase',
        dob: dob ?? DateTime.now(),
      ),
    );
  }

  void showErrorMessage(String message) {
    UIUtil.showDialogOrigin(
        child: NotifyDialog(
          content: message,
          textButton: Lang.common_close.tr(),
        ),
        context: context);
  }

  @override
  void dispose() {
    _registerBloc.close();
    for (var controller in listOtpFields) {
      controller.dispose();
    }
    super.dispose();
  }
}
