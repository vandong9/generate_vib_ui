part of 'splash_bloc.dart';

@immutable
abstract class SplashEvent {}

class CheckUserLogin extends SplashEvent {}

class FetchConfig extends SplashEvent {}

class FetchConfigBackground extends SplashEvent {}

