part of 'splash_bloc.dart';

@immutable
abstract class SplashState extends Equatable {
  @override
  List<Object?> get props => [];
}

class Logged extends SplashState {
  final UserInfo userInfo;

  Logged(this.userInfo);

  @override
  List<Object?> get props => [
        userInfo,
      ];
}

class InitState extends SplashState {
  final UserInfo? userInfo;
  final ConfigModel? configModel;

  InitState({
    this.configModel,
    required this.userInfo,
  });

  @override
  List<Object?> get props => [
        configModel,
        userInfo,
      ];
}

class SignedOut extends SplashState {}

class LoadStartedContent extends SplashState {}
