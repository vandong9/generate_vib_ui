import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:floralpunk/common/widget/base/bloc/base_bloc.dart';
import 'package:floralpunk/data/model/config_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:meta/meta.dart';

import '../../../common/di/injection/injector.dart';
import '../../../data/model/user_info.dart';
import '../../../data/repository/config_repository.dart';
import '../../../data/repository/user_repository.dart';

part 'splash_event.dart';

part 'splash_state.dart';

class SplashBloc extends Bloc<SplashEvent, SplashState> {
  final UserRepository userRepository;
  final ConfigRepository configRepository;

  SplashBloc({
    required this.userRepository,
    required this.configRepository,
  }) : super(InitState(
          userInfo: userRepository.getCurrentUser(),
        )) {
    on<SplashEvent>((event, emit) async {
      if (event is FetchConfig) {
        // ignore: unawaited_futures
        // final result = await configRepository.fetchConfig();
        await Future.delayed(Duration(milliseconds: 3000));
        emit.call(_determineSession());
      } else if (event is FetchConfigBackground) {
        // await Future.value([
        //   configRepository.fetchConfig(),
        // ]);
        await Future.delayed(Duration(milliseconds: 3000));
        emit.call(_determineSession());
      } else if (event is CheckUserLogin) {
        emit.call(_determineSession());
      }
    });
  }

  SplashState _determineSession() {
    final user = userRepository.getCurrentUser();
    if (user != null) {
      return Logged(user);
    } else {
      return SignedOut();
    }
  }
}
