import 'package:after_layout/after_layout.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:floralpunk/common/constants/constants.dart';
import 'package:floralpunk/main.dart';
import 'package:floralpunk/ui/intro/intro_page.dart';
import 'package:floralpunk/utils/navigate_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../common/di/injection/injector.dart';
import '../../common/theme/theme.dart';
import '../../common/widget/base/base_widget.dart';
import '../../data/repository/config_repository.dart';
import '../../data/repository/user_repository.dart';
import '../home/home_page.dart';
import '../login/login_page.dart';
import 'bloc/splash_bloc.dart';

class SplashScreen extends BaseWidget {
  static const routeName = 'SplashScreen';

  const SplashScreen();

  @override
  State<StatefulWidget> createState() {
    return SplashScreenState();
  }
}

class SplashScreenState extends BaseState<SplashScreen>
    with AfterLayoutMixin, TickerProviderStateMixin {
  final SplashBloc _splashBloc = sl<SplashBloc>();

  @override
  void initState() {
    super.initState();
    //Call this method first when LoginScreen init
    initBasicInfo();
  }

  void initBasicInfo() {
    _splashBloc.stream.listen((state) {
      if (state is Logged) {
        NavigateUtil.openPage(context, HomeScreen.routeName);
      } else if (state is SignedOut) {
        if (mounted) {
          NavigateUtil.openPage(context, IntroScreen.routeName);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return Container(
        width: constraints.maxWidth,
        height: constraints.maxHeight,
        color: ThemeColor.whiteColor,
        child: BlocProvider(
            create: (_) => _splashBloc,
            child:
                BlocBuilder<SplashBloc, SplashState>(builder: (context, state) {
              final currentState = state;
              if (currentState is InitState) {
                return Stack(
                  children: [
                    Center(
                      child: Text(
                        Lang.splash_floral_punk.tr(),
                        style: textLargexxx.copyWith(
                          color: ThemeColor.blackColor,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    const Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: EdgeInsets.only(
                          bottom: sizeLarge,
                        ),
                        child: SizedBox(
                          height: sizeLarge,
                          width: sizeLarge,
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation(
                              ThemeColor.blackColor,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              }
              return const SizedBox();
            })),
      );
    });
  }

  @override
  void dispose() {
    if (mounted) {
      _splashBloc.close();
    }
    super.dispose();
  }

  @override
  void afterFirstLayout(BuildContext context) {
    checkInitWidget(context);
  }

  Future<void> checkInitWidget(BuildContext context) async {
    final userRepository = sl<UserRepository>();
    final userInfo = userRepository.getCurrentUser();
    // Get any messages which caused the application to open from
    // a terminated state.
    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();

    // If the message also contains a data property with a "type" of "event|amenity|post",
    // navigate to a detail page
    if (BaseState.checkDirectNotification(context, initialMessage)) {
      return;
    }

    if (userInfo != null && (userInfo.accessToken?.isNotEmpty ?? false)) {
      _splashBloc.add(FetchConfigBackground());
    } else {
      _splashBloc.add(FetchConfig());
    }
  }
}
