part of 'login_bloc.dart';

@immutable
abstract class LoginState extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoginInitial extends LoginState {}

class LoginSuccess extends LoginState {
  final FloralPunk.UserInfo userInfo;

  LoginSuccess({
    required this.userInfo,
  });

  @override
  List<Object?> get props => [
        userInfo,
      ];
}

class LoginFail extends LoginState {
  final String message;
  final String refreshTime;
  final String firebaseToken;
  final UserCredential userCredential;

  LoginFail({
    required this.message,
    required this.refreshTime,
    required this.firebaseToken,
    required this.userCredential,
  });

  @override
  List<Object?> get props => [
        refreshTime,
        userCredential,
    firebaseToken,
        message,
      ];
}
