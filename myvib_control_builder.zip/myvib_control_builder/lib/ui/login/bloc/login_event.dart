part of 'login_bloc.dart';

@immutable
abstract class LoginEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class DoLogin extends LoginEvent {
  final String userName;
  final String phoneNumber;
  final String firebaseToken;
  final String provider;
  final UserCredential userCredential;

  DoLogin({
    required this.userName,
    required this.phoneNumber,
    required this.firebaseToken,
    required this.userCredential,
    required this.provider,
  });

  @override
  List<Object?> get props => [
        userName,
        phoneNumber,
        firebaseToken,
        provider,
        userCredential,
      ];
}
