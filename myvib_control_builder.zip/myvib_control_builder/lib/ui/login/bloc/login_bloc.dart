import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

import '../../../common/di/injection/injector.dart';
import '../../../common/widget/base/bloc/base_bloc.dart';
import '../../../data/model/user_info.dart' as FloralPunk;
import '../../../data/repository/user_repository.dart';
import '../../../data/source/failure.dart';

part 'login_event.dart';

part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final UserRepository userRepository;

  LoginBloc({
    required this.userRepository,
  }) : super(LoginInitial()) {
    on<LoginEvent>((event, emit) async {
      if (event is DoLogin) {
        final result = await userRepository.login(
          fullName: event.userName,
          phoneNumber: event.phoneNumber,
          firebaseToken: event.firebaseToken,
          provider: event.provider,
        );
        emit.call(result.fold(
            (l) => LoginFail(
                  message: (l as RemoteDataFailure).errorMessage,
                  refreshTime: DateTime.now().millisecondsSinceEpoch.toString(),
                  userCredential: event.userCredential,
                  firebaseToken: event.firebaseToken,
                ), (r) {
          sl<BaseBloc>().add(Init());
          return LoginSuccess(
            userInfo: r,
          );
        }));
      }
    });
  }
}
