import 'package:floralpunk/common/theme/theme.dart';
import 'package:floralpunk/common/widget/buttons/my_button.dart';
import 'package:floralpunk/common/widget/buttons/my_button.icon.dart';
import 'package:floralpunk/utils/firebase_wrapper.dart';
import 'package:floralpunk/utils/navigate_util.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../common/constants/constants.dart';
import '../../common/di/injection/injector.dart';
import '../../common/dialog/notify_dialog.dart';
import '../../common/theme/theme.dart';
import '../../common/widget/base/base_widget.dart';
import '../../common/widget/buttons/my_button.dart';
import '../../common/widget/buttons/my_button.icon.dart';
import '../../utils/navigate_util.dart';
import '../../utils/ui_util.dart';
import '../home/home_page.dart';
import '../register/register_page.dart';
import 'bloc/login_bloc.dart';
import 'dart:io' show Platform;

class LoginScreen extends BaseWidget {
  static const routeName = '/LoginScreen';

  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return LoginScreenState();
  }
}

class LoginScreenState extends BaseState<LoginScreen> {
  final LoginBloc _loginBloc = sl<LoginBloc>();

  @override
  void initState() {
    super.initState();
    //Call this method first when LoginScreen init
    initBasicInfo();
  }

  void initBasicInfo() {
    _loginBloc.stream.listen((state) {
      if (pbLoading?.isShowing() ?? false) {
        pbLoading?.hide();
      }
      if (state is LoginFail) {
        UIUtil.showDialogOrigin(
            child: NotifyDialog(
              content: state.message,
              textButton: Lang.common_close.tr(),
              optionalWidget: GestureDetector(
                onTap: () {
                  NavigateUtil.pop(context);
                  NavigateUtil.openPage(
                    context,
                    RegisterScreen.routeName,
                    argument: {
                      'fullName': state.userCredential.user?.displayName ?? '',
                      'phoneNumber':
                          state.userCredential.user?.phoneNumber ?? '',
                      'firebaseToken': state.firebaseToken,
                    },
                  );
                },
                child: Container(
                  padding: const EdgeInsets.only(
                    bottom: sizeIcon,
                  ),
                  margin: const EdgeInsets.only(
                    bottom: sizeSmall,
                  ),
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: ThemeColor.blackColor,
                        width: 1,
                      ),
                    ),
                  ),
                  child: Text(
                    Lang.login_become_a_member.tr() + '?',
                    style: textNormalxx.copyWith(
                        color: ThemeColor.blackColor,
                        fontWeight: FontWeight.w300,
                        fontFamily: MyFontFamily.Helvetica),
                  ),
                ),
              ),
            ),
            context: context);
      }
      if (state is LoginSuccess) {
        NavigateUtil.openPage(context, HomeScreen.routeName);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    initDialogLoading(context);
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Scaffold(
          appBar: AppBar(
            title: Text(Lang.login_sign_in.tr()),
            titleTextStyle: textNormal.copyWith(
              color: ThemeColor.blackColor,
              fontWeight: FontWeight.w300,
            ),
            leading: IconButton(
              icon: SvgPicture.asset(
                Res.ic_arrow_back,
                color: Colors.black,
              ),
              onPressed: () => Navigator.of(context).pop(),
            ),
            titleSpacing: 0,
            backgroundColor: ThemeColor.whiteColor,
            shadowColor: ThemeColor.transparent,
            bottom: PreferredSize(
              child: Container(
                color: Colors.black,
                height: 1.0,
              ),
              preferredSize: const Size.fromHeight(1),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.only(
              left: sizeNormal,
              right: sizeNormal,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: Lang.login_welcome.tr(),
                        style: textLargexxx.copyWith(
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      TextSpan(
                        text: " " + Lang.login_to.tr() + '\n',
                        style: textLargex.copyWith(
                          fontWeight: FontWeight.w300,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                      TextSpan(
                        text: Lang.login_floral_punk.tr() + '\n',
                        style: textLargexxx.copyWith(
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      TextSpan(
                        text: Lang.login_please_sign_in_to_your_account.tr(),
                        style: textNormalxxx.copyWith(
                          fontWeight: FontWeight.w300,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    MyButtonIcon(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SvgPicture.asset(
                            Res.ic_facebook,
                            width: sizeNormal,
                            color: ThemeColor.whiteColor,
                          ),
                          const SizedBox(
                            width: sizeSmallx,
                          ),
                          Text(
                            Lang.login_sign_in_with_facebook.tr(),
                            style: textNormal.copyWith(
                              fontWeight: FontWeight.w300,
                              color: ThemeColor.whiteColor,
                              fontFamily: MyFontFamily.Helvetica,
                            ),
                          )
                        ],
                      ),
                      buttonStyle: styleButtonColor_2,
                      radius: 0,
                      onTap: () {
                        doSocialLogin(
                          type: 'facebook',
                        );
                      },
                    ),
                    const SizedBox(
                      height: sizeSmallx,
                    ),
                    if (Platform.isAndroid)
                      MyButtonIcon(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              Res.ic_google,
                              width: sizeNormal,
                              color: ThemeColor.blackColor,
                            ),
                            const SizedBox(
                              width: sizeSmallx,
                            ),
                            Text(
                              Lang.login_sign_in_with_google.tr(),
                              style: textNormal.copyWith(
                                fontWeight: FontWeight.w300,
                                color: ThemeColor.blackColor,
                                fontFamily: MyFontFamily.Helvetica,
                              ),
                            )
                          ],
                        ),
                        isOutline: true,
                        buttonStyle: styleButtonColor_2,
                        radius: 0,
                        onTap: () {
                          doSocialLogin(
                            type: 'google',
                          );
                        },
                      ),
                    const SizedBox(
                      height: sizeSmallx,
                    ),
                    if (Platform.isIOS)
                      MyButtonIcon(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              Res.ic_apple,
                              width: sizeNormal,
                              color: ThemeColor.blackColor,
                            ),
                            const SizedBox(
                              width: sizeSmallx,
                            ),
                            Text(
                              Lang.login_sign_in_with_apple.tr(),
                              style: textNormal.copyWith(
                                fontWeight: FontWeight.w300,
                                color: ThemeColor.blackColor,
                                fontFamily: MyFontFamily.Helvetica,
                              ),
                            )
                          ],
                        ),
                        isOutline: true,
                        buttonStyle: styleButtonColor_2,
                        radius: 0,
                        onTap: () {
                          doSocialLogin(
                            type: 'apple',
                          );
                        },
                      ),
                    const SizedBox(
                      height: sizeNormalx,
                    ),
                    GestureDetector(
                      onTap: () {
                        NavigateUtil.openPage(
                            context, RegisterScreen.routeName);
                      },
                      child: Container(
                        padding: const EdgeInsets.only(
                          bottom: sizeIcon,
                        ),
                        decoration: const BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: ThemeColor.blackColor,
                              width: 1,
                            ),
                          ),
                        ),
                        child: Text(
                          Lang.login_become_a_member.tr(),
                          style: textNormalxx.copyWith(
                              color: ThemeColor.blackColor,
                              fontWeight: FontWeight.w300,
                              fontFamily: MyFontFamily.Helvetica),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void doSocialLogin({
    required String type,
  }) async {
    // await pbLoading?.show();
    // (type == 'facebook'
    //         ? sl<FirebaseWrapper>().signInWithFacebook()
    //         : (type == 'google'
    //             ? sl<FirebaseWrapper>().signInWithGoogle()
    //             : sl<FirebaseWrapper>().signInWithApple()))
    //     .then((userCredential) async {
    //   _loginBloc.add(
    //     DoLogin(
    //       userName: userCredential.user?.displayName ?? '',
    //       phoneNumber: userCredential.user?.phoneNumber ?? '',
    //       firebaseToken: (await userCredential.user?.getIdToken()) ?? '',
    //       provider: 'Firebase',
    //       userCredential: userCredential,
    //     ),
    //   );
    // }).catchError((error, stackTrace) {
    //   pbLoading?.hide();
    //   UIUtil.showDialogOrigin(
    //       child: NotifyDialog(
    //         content: error.toString(),
    //         textButton: Lang.common_close.tr(),
    //       ),
    //       context: context);
    // });
  }

  @override
  void dispose() {
    _loginBloc.close();
    super.dispose();
  }
}
