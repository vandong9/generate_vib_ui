import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'common/constants/constants.dart';
import 'common/di/injection/injector.dart';
import 'common/dialog/notify_dialog.dart';
import 'common/theme/theme.dart';
import 'common/widget/base/base_widget.dart';
import 'data/repository/user_repository.dart';
import 'data/source/api_end_point.dart';
import 'my_custom_route.dart';
import 'ui/splash/splash_page.dart';
import 'utils/date_util.dart';
import 'utils/notification_action.dart';
import 'utils/ui_util.dart';

class Application extends StatelessWidget {
  // This widget is the root of your application.
  static late BuildContext currentContext;

  @override
  Widget build(BuildContext context) {
    // updateLangEndPoint(context.locale);

    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Floral Punk',
          localizationsDelegates: [DefaultCupertinoLocalizations.delegate],
          onGenerateRoute: myRoute,
          theme: defaultTheme(),
          home: SplashScreen(),
        ));
  }
}
