import 'package:dartz/dartz.dart';
import '../model/config_model.dart';
import '../model/item_model.dart';
import '../source/failure.dart';
import '../source/local/config_local_data_source.dart';
import '../source/remote/config_remote_data_source.dart';
import 'repository.dart';

abstract class ConfigRepository extends ConfigLocalDataSource {
  Future<Either<Failure, ConfigModel>> fetchConfig();

  Future<Either<Failure, List<ItemModel>>> fetchItems();
}

class ConfigRepositoryImpl extends Repository implements ConfigRepository {
  final ConfigRemoteDataSource remoteDataSource;
  final ConfigLocalDataSource localDataSrc;

  ConfigRepositoryImpl(
      {required this.remoteDataSource, required this.localDataSrc});

  @override
  Future<Either<Failure, ConfigModel>> fetchConfig() async {
    return catchData<ConfigModel>(() async {
      final data = await remoteDataSource.fetchConfig();
      saveConfig(data);
      return data;
    });
  }

  @override
  ConfigModel? getConfig() {
    return localDataSrc.getConfig();
  }

  @override
  void saveConfig(ConfigModel configModel) {
    localDataSrc.saveConfig(configModel);
  }

  @override
  List<ItemModel>? getItemList() {
    return localDataSrc.getItemList();
  }

  @override
  void saveItemList(List<ItemModel> list) {
    localDataSrc.saveItemList(list);
  }

  @override
  Future<Either<Failure, List<ItemModel>>> fetchItems() async {
    return catchData<List<ItemModel>>(() async {
      final data = await remoteDataSource.fetchItems();
      saveItemList(data);
      return data;
    });
  }
}
