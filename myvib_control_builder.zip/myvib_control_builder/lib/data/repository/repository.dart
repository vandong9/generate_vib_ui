import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import '../../common/di/injection/injector.dart';
import '../../utils/network_info.dart';
import '../../utils/ui_util.dart';
import '../source/failure.dart';

class Repository {
  final NetworkInfo networkInfo = sl<NetworkInfo>();
  Locale? _currentLocal;

  Locale get currentLocal => _currentLocal!;

  set currentLocal(Locale currentLocal) => _currentLocal = currentLocal;

  Future<Either<Failure, T>> catchData<T>(Function action) async {
    if (await networkInfo.isConnected) {
      try {
        return Right(await action() as T);
      } on RemoteDataFailure catch (e) {
        print('RemoteDataFailure');
        print(e.errorMessage);
        return Left(e);
      } on DioError catch (e) {
        print('DioError');
        var mess = e.response?.statusMessage;
        final errorResponseData = e.response?.data;
        if (errorResponseData != null && errorResponseData is List) {
          mess = errorResponseData.join(',');
          // UIUtil.showToast(mess);
        } else if (errorResponseData != null &&
            errorResponseData is Map &&
            errorResponseData.containsKey('responseStatus')) {
          mess = errorResponseData['responseStatus']['message'];
          UIUtil.showToast(mess);
        } else if (errorResponseData != null) {
          mess = errorResponseData.toString();
          UIUtil.showToast(mess);
        }
        return Left(
            RemoteDataFailure(errorCode: e.toString(), errorMessage: mess!));
      } on Exception catch (e) {
        print('Exception');
        return Left(RemoteDataFailure(
            errorCode: e.toString(), errorMessage: e.toString()));
      }
    } else {
      print('NetworkFailure');
      return Left(NetworkFailure());
    }
  }
}
