import 'package:dartz/dartz.dart';

import '../../common/di/injection/injector.dart';
import '../../utils/app_const.dart';
import '../../utils/date_util.dart';
import '../model/user_info.dart';
import '../source/failure.dart';
import '../source/local/user_local_data_source.dart';
import '../source/remote/user_remote_data_source.dart';
import '../source/success.dart';
import 'repository.dart';

abstract class UserRepository {
  Future<Either<Failure, Success>> logout();

  void saveCurrentUser(UserInfo user);

  UserInfo? getCurrentUser();

  Future<Either<Failure, UserInfo>> login({
    required String fullName,
    required String phoneNumber,
    required String firebaseToken,
    required String provider,
    String? dob,
  });

  Future<Either<Failure, UserInfo>> register({
    required String username,
    required String password,
    required String email,
    required String phoneNumber,
  });
}

class UserRepositoryImpl extends Repository implements UserRepository {
  final UserRemoteDataSource remoteDataSource;
  final UserLocalDataSource localDataSrc;

  UserRepositoryImpl(
      {required this.remoteDataSource, required this.localDataSrc});

  @override
  void saveCurrentUser(UserInfo user) {
    return localDataSrc.saveUser(user);
  }

  @override
  UserInfo? getCurrentUser() {
    final userInfo = localDataSrc.getCurrentUser();
    return userInfo;
  }

  @override
  Future<Either<Failure, Success>> logout() async {
    return catchData<Success>(() async {
      final data = await localDataSrc.logout();
      return data;
    });
  }

  @override
  Future<Either<Failure, UserInfo>> login({
    required String fullName,
    required String phoneNumber,
    required String firebaseToken,
    required String provider,
    String? dob,
  }) async {
    return catchData<UserInfo>(() async {
      final data = await remoteDataSource.login(
        fullName: fullName,
        phoneNumber: phoneNumber,
        firebaseToken: firebaseToken,
        provider: provider,
        dob: dob,
      );
      saveCurrentUser(data);
      return data;
    });
  }

  @override
  Future<Either<Failure, UserInfo>> register({
    required String username,
    required String password,
    required String email,
    required String phoneNumber,
  }) async {
    return catchData<UserInfo>(() async {
      final data = await remoteDataSource.register(
        username: username,
        password: password,
        email: email,
        phoneNumber: phoneNumber,
      );
      return data;
    });
  }
}
