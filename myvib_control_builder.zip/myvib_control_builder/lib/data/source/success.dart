class Success {}
