//Current environment
const KIOSK_VIET = "https://id.kiotviet.vn/";
const KIOSK_VIET_API = "https://public.kiotapi.com/";

//Default Language code
String langCode = 'vi-VN';

String get endPointGetToken => '${KIOSK_VIET}connect/token';

// End point Invoice
String get endPointInvoice => '${KIOSK_VIET_API}invoices';

String endPointGetInvoices({
  String branchIds = '',
  String customerIds = '',
  String customerCode = '',
  String status = '',
  bool includePayment = true,
  bool includeInvoiceDelivery = true,
  int pageSize = 100,
  int currentItem = 0,
  String lastModifiedFrom = '',
  String toDate = '',
  String orderBy = 'name',
  String orderDirection = 'Desc',
  String orderId = '',
  String createdDate = '',
  String fromPurchaseDate = '',
  String toPurchaseDate = '',
}) =>
    '$endPointInvoice?customerIds=$customerIds&customerCode=$customerCode&'
    'branchIds=$branchIds&status=$status&includePayment=$includePayment&'
    'includeInvoiceDelivery=$includeInvoiceDelivery&'
    'pageSize=$pageSize&currentItem=$currentItem&lastModifiedFrom=$lastModifiedFrom&'
    'toDate=$toDate&orderDirection=$orderDirection&orderId=$orderId&createdDate=$createdDate'
    '&fromPurchaseDate=$fromPurchaseDate&toPurchaseDate=$toPurchaseDate';

String endPointInvoicesWithId({
  required String id,
}) =>
    '$endPointInvoice/$id';

String endPointInvoicesWithCode({
  required String Code,
}) =>
    '$endPointInvoice/$Code';

// End point Customer
String get endCustomer => '${KIOSK_VIET_API}customers';

String endPointCustomerWithCode({
  required String code,
}) =>
    '$endCustomer/code/$code';

String endPointCustomerWithId({
  required String id,
}) =>
    '$endCustomer/$id';

// End point Products
String get endProducts => '${KIOSK_VIET_API}products';

String endPointGetItemList({
  String format = 'json',
  int currentItem = 0,
  int pageSize = 100,
  bool includeInventory = true,
  bool isActive = true,
  bool includePricebook = true,
  String orderBy = 'id',
  String orderDirection = 'desc',
  String? lastModifiedFrom,
}) =>
    '$endProducts?format=$format&currentItem=$currentItem&'
    'includeInventory=$includeInventory&isActive=$isActive&includePricebook=$includePricebook&'
    'pageSize=$pageSize&orderBy=$orderBy&orderDirection=$orderDirection'
    '${lastModifiedFrom != null ? '&lastModifiedFrom=$lastModifiedFrom' : ''}';

String endPointGetItemWithCode({
  required String code,
}) =>
    '$endProducts/code/$code';

String endPointItemWithId({
  required String id,
}) =>
    '$endProducts/$id';

// End point Categories
String get endCategory => '${KIOSK_VIET_API}categories';

String endPointGetCategory({
  String format = 'json',
  bool includeRemoveIds = true,
  int pageSize = 0,
  int currentItem = 0,
  String orderBy = 'categoryName',
  String orderDirection = 'desc',
  bool hierachicalData = true,
  String? lastModifiedFrom,
}) =>
    '$endCategory?format=$format'
    '&includeRemoveIds=$includeRemoveIds&pageSize=$pageSize&currentItem=$currentItem'
    '&orderBy=$orderBy&orderDirection=$orderDirection'
    '&hierachicalData=$hierachicalData'
    '${lastModifiedFrom != null ? '&lastModifiedFrom=$lastModifiedFrom' : ''}';

String endPointCategoryWithId({
  required String id,
}) =>
    '$endCategory/$id';

const int CODE_SUCCESS = 200;
const int CODE_CREATE = 201;
const int CODE_LINK_ACCOUNT = 101;
const int CODE_BAD_REQUEST = 400;
const int CODE_SERVER_ERROR = 500;
const int CODE_UN_AUTH = 401;
const int CODE_CUSTOM_ACTIVATE_ACCOUNT = 100;
