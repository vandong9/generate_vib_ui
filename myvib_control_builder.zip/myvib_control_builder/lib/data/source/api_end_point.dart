import 'dart:math';

import 'package:flutter/material.dart';

import '../../common/di/injection/injector.dart';
import '../../utils/environment_info.dart';
import '../model/user_info.dart';

//Current environment
final EnvironmentInfo env = sl<EnvironmentInfo>();

//Default Language code
String langCode = 'vi-VN';

String get baseEndPoint => '${env.host}/';
// String get baseEndPoint => '${env.host}/${env.apiVersion}/';

String get endPointLogin => '${baseEndPoint}api/floralpunk/account/external-login';

String get endPointRefreshToken =>
    '${baseEndPoint}api/v2/rest/mix-account/user/renew-token';

String get endPointRegister =>
    '${baseEndPoint}api/v2/rest/mix-account/user/register';

const int CODE_SUCCESS = 200;
const int CODE_CREATE = 201;
const int CODE_LINK_ACCOUNT = 101;
const int CODE_BAD_REQUEST = 400;
const int CODE_SERVER_ERROR = 500;
const int CODE_UN_AUTH = 401;
const int CODE_CUSTOM_ACTIVATE_ACCOUNT = 100;

/*
 * Update latest lang in api
 * Locale - current language
 */
void updateLangEndPoint(Locale locale) {
  // langCode = '${locale.languageCode}-${locale.countryCode}';
  langCode = '${locale.languageCode}';
}
