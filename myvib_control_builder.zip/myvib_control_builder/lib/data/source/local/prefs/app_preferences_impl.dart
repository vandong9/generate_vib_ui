import 'dart:convert';

import 'package:hive/hive.dart';
import '../../../../utils/utils.dart';
import '../../../model/user_info.dart';

import 'app_preferences.dart';

class AppPreferencesImpl extends AppPreferences {
  final Box box;

  AppPreferencesImpl({
    required this.box,
  });

  @override
  String? getUserInfo() {
    return box.get(AppPreferences.CACHED_CURRENT_USER, defaultValue: null);
  }

  @override
  void saveUserInfo(UserInfo userInfo) {
    final str = userInfo.toJson();
    final encryptJson = Utils.encData(json.encode(str));

    box.put(AppPreferences.CACHED_CURRENT_USER, encryptJson);
  }

  @override
  Future<void> clearUserData() async {
    await box.clear();
    if (box.containsKey( AppPreferences.CACHED_CURRENT_USER)) {
      await box.delete( AppPreferences.CACHED_CURRENT_USER);
    }
    if (box.containsKey( AppPreferences.CACHED_CONFIG)) {
      await box.delete( AppPreferences.CACHED_CONFIG);
    }
    if (box.containsKey( AppPreferences.CACHED_ITEM_LIST)) {
      await box.delete( AppPreferences.CACHED_ITEM_LIST);
    }
  }

  @override
  String? getConfig() {
    return box.get( AppPreferences.CACHED_CONFIG,
        defaultValue: null);
  }

  @override
  void saveConfig(String? data) {
    box.put( AppPreferences.CACHED_CONFIG, data);
  }

  @override
  String? getItemList() {
    return box.get( AppPreferences.CACHED_ITEM_LIST,
        defaultValue: null);
  }

  @override
  void saveItemList(String? data) {
    box.put( AppPreferences.CACHED_ITEM_LIST, data);
  }
}
