import '../../../model/user_info.dart';

abstract class AppPreferences {
  void saveUserInfo(UserInfo listUsers);

  String? getUserInfo();

  void saveConfig(String? data);

  String? getConfig();
  void saveItemList(String? data);

  String? getItemList();

  Future<void> clearUserData();

  static const CACHED_CONFIG = 'CACHED_CONFIG';
  static const CACHED_CURRENT_USER = 'CACHED_CURRENT_USER';
  static const CACHED_ITEM_LIST = 'CACHED_ITEM_LIST';
}
