import 'dart:convert';
import '../../model/config_model.dart';
import '../../model/item_model.dart';
import 'prefs/app_preferences.dart';

abstract class ConfigLocalDataSource {
  ConfigModel? getConfig();

  void saveConfig(ConfigModel configModel);

  void saveItemList(List<ItemModel> list);

  List<ItemModel>? getItemList();
}

class ConfigLocalDataSourceImpl implements ConfigLocalDataSource {
  final AppPreferences appPreferences;

  ConfigLocalDataSourceImpl({required this.appPreferences});

  @override
  ConfigModel? getConfig() {
    try {
      final jsonString = appPreferences.getConfig();
      if (jsonString != null) {
        return ConfigModel.fromJson(json.decode(jsonString));
      } else {
        return null;
      }
    } on Exception catch (exception) {
      print(exception);
      return null;
    } catch (error) {
      print(error);
      return null;
    }
  }

  @override
  void saveConfig(ConfigModel configModel) {
    return appPreferences.saveConfig(json.encode(configModel.toJson()));
  }

  @override
  List<ItemModel>? getItemList() {
    try {
      final jsonString = appPreferences.getItemList();
      if (jsonString != null) {
        final List<dynamic> strMap = json.decode(jsonString);
        final data = strMap.map((v) => ItemModel.fromJson(v)).toList();
        return data;
      } else {
        return null;
      }
    } on Exception catch (exception) {
      print(exception);
      return null;
    } catch (error) {
      print(error);
      return null;
    }
  }

  @override
  void saveItemList(List<ItemModel> list) {
    final str = list.map((v) => v.toJson()).toList();
    return appPreferences.saveItemList(json.encode(str));
  }
}
