import 'dart:convert';

import '../../../utils/utils.dart';
import '../../model/user_info.dart';
import '../success.dart';
import 'prefs/app_preferences.dart';

abstract class UserLocalDataSource {
  UserInfo? getCurrentUser();

  Future<Success> logout();

  void saveUser(UserInfo userInfo);
}

class UserLocalDataSourceImpl implements UserLocalDataSource {
  final AppPreferences appPreferences;

  UserLocalDataSourceImpl({required this.appPreferences});

  @override
  UserInfo? getCurrentUser() {
    try {
      final jsonString = appPreferences.getUserInfo();
      if (jsonString != null) {
        final decJson = Utils.decData(jsonString);
        return UserInfo.fromJson(json.decode(decJson));
      } else {
        return null;
      }
    } on Exception catch (exception) {
      print(exception);
      return null;
    } catch (error) {
      print(error);
      return null;
    }
  }

  @override
  Future<void> saveUser(UserInfo userInfo) async {
    return appPreferences.saveUserInfo(userInfo);
  }

  @override
  Future<Success> logout() async {
    await appPreferences.clearUserData();
    return Success();
  }
}
