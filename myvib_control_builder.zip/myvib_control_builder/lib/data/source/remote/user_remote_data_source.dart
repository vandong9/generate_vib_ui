import 'dart:convert';
import '../../../utils/string_util.dart';
import '../../model/user_info.dart';
import '../api_end_point.dart';
import '../success.dart';
import 'remote_base.dart';
import 'dart:developer' as MyLog;

abstract class UserRemoteDataSource with RemoteBase {
  Future<UserInfo> login({
    required String fullName,
    required String phoneNumber,
    required String firebaseToken,
    String? dob,
    required String provider,
  });

  Future<UserInfo> register({
    required String username,
    required String password,
    required String email,
    required String phoneNumber,
  });
}

class UserRemoteDataSourceImpl extends RemoteBaseImpl
    implements UserRemoteDataSource {
  @override
  Future<UserInfo> login({
    required String fullName,
    required String phoneNumber,
    required String firebaseToken,
    String? dob,
    required String provider,
  }) async {
    setPublicToken();
    final response = await dio.post(endPointLogin, data: {
      'phoneNumber': phoneNumber,
      'externalAccessToken': firebaseToken,
      'provider': provider,
      'data': {'name': fullName, "birthDate": dob}
    });
    MyLog.log('firebaseToken ' +
        json.encode({
          'phoneNumber': phoneNumber,
          'externalAccessToken': firebaseToken,
          'provider': provider,
          'data': {'name': fullName, "birthDate": dob}
        }));

    return checkStatusCode<UserInfo>(response, (responseData) {
      return UserInfo.fromJson(responseData);
    });
  }

  @override
  Future<UserInfo> register({
    required String username,
    required String password,
    required String email,
    required String phoneNumber,
  }) async {
    setPublicToken();
    final response = await dio.post(endPointRegister, data: {
      'email': email,
      'password': password,
      'username': username,
      'phoneNumber': phoneNumber,
    });
    return checkStatusCode<UserInfo>(response, (responseData) {
      return UserInfo.fromJson(responseData);
    });
  }
}
