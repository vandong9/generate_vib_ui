import '../../model/config_model.dart';
import '../../model/item_model.dart';
import '../api_end_point.dart';
import '../kiosk_api_end_point.dart';
import 'remote_base.dart';

abstract class ConfigRemoteDataSource with RemoteBase {
  Future<ConfigModel> fetchConfig();

  Future<List<ItemModel>> fetchItems();
}

class ConfigRemoteDataSourceImpl extends RemoteBaseImpl
    implements ConfigRemoteDataSource {
  @override
  Future<ConfigModel> fetchConfig() async {
    setPublicToken();
    final response = await dio.post(endPointGetToken, data: {
      'client_id': env.clientId,
      'client_secret': env.clientSecret,
      'grant_type': 'client_credentials',
      'scopes': 'PublicApi.Access',
    });
    return checkStatusCode<ConfigModel>(response, (responseData) {
      return ConfigModel.fromJson(responseData);
    });
  }

  @override
  Future<List<ItemModel>> fetchItems() async {
    final response = await dio.get(endPointGetItemList());
    return checkStatusCode<List<ItemModel>>(response, (responseData) {
      final List<dynamic> strMap = responseData['data'];
      return strMap.map((v) => ItemModel.fromJson(v)).toList();
    });
  }
}
