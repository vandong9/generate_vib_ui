import 'package:equatable/equatable.dart';

import '../../utils/log_utils.dart';

class ConfigModel extends Equatable {
  final String? accessToken;

  const ConfigModel({
    this.accessToken,
  });

  ConfigModel copyWith({
    String? accessToken,
  }) {
    return ConfigModel(
      accessToken: accessToken ?? this.accessToken,
    );
  }

  factory ConfigModel.fromJson(Map<String, dynamic> json) {
    try {
      final configModel = ConfigModel(
        accessToken: json['access_token'],
      );
      return configModel;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }
    throw 'Wrong data null';
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    try {
      data['access_token'] = accessToken;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }

    return data;
  }

  @override
  List<Object?> get props => [
        accessToken,
      ];
}
