import 'package:equatable/equatable.dart';

import '../../utils/log_utils.dart';

class UserInfo extends Equatable {
  final String? accessToken;
  final String? tokenType;
  final String? refreshToken;
  final Info? info;

  UserInfo({
    this.accessToken,
    this.tokenType,
    this.refreshToken,
    this.info,
  });

  UserInfo copyWith({
    String? accessToken,
    String? tokenType,
    String? refreshToken,
    Info? info,
  }) {
    return UserInfo(
      accessToken: accessToken ?? this.accessToken,
      tokenType: tokenType ?? this.tokenType,
      refreshToken: refreshToken ?? this.refreshToken,
      info: info ?? this.info,
    );
  }

  factory UserInfo.fromJson(Map<String, dynamic> json) {
    try {
      final userInfo = UserInfo(
        accessToken: json['accessToken'],
        tokenType: json['tokenType'],
        refreshToken: json['refreshToken'],
        info: json.containsKey('info') ? Info.fromJson(json['info']) : null,
      );
      return userInfo;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }
    throw 'Wrong data null';
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    try {
      data['accessToken'] = accessToken;
      data['tokenType'] = tokenType;
      data['refreshToken'] = refreshToken;
      if (info != null) {
        data['info'] = info?.toJson();
      }
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }

    return data;
  }

  @override
  List<Object?> get props => [
        accessToken,
        tokenType,
        refreshToken,
        info,
      ];
}

class Info extends Equatable {
  final String? id;
  final String? userName;
  final String? email;
  final bool? isActived;
  final String? phoneNumber;

  Info({
    this.id,
    this.userName,
    this.email,
    this.isActived,
    this.phoneNumber,
  });

  Info copyWith({
    String? id,
    String? userName,
    String? email,
    bool? isActived,
    String? phoneNumber,
  }) {
    return Info(
      id: id ?? this.id,
      userName: userName ?? this.userName,
      email: email ?? this.email,
      isActived: isActived ?? this.isActived,
      phoneNumber: phoneNumber ?? this.phoneNumber,
    );
  }

  factory Info.fromJson(Map<String, dynamic> json) {
    try {
      final info = Info(
        id: json['id'],
        userName: json['userName'],
        email: json['email'],
        isActived: json['isActived'],
        phoneNumber: json['phoneNumber'],
      );
      return info;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }
    throw 'Wrong data null';
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    try {
      data['id'] = id;
      data['userName'] = userName;
      data['email'] = email;
      data['isActived'] = isActived;
      data['phoneNumber'] = phoneNumber;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }

    return data;
  }

  @override
  List<Object?> get props => [
        id,
        userName,
        email,
        isActived,
        phoneNumber,
      ];
}
