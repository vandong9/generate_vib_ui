import 'package:equatable/equatable.dart';

import '../../utils/log_utils.dart';

class ItemModel extends Equatable {
  final String? createdDate;
  final int? id;
  final int? retailerId;
  final String? code;
  final String? name;
  final String? fullName;
  final int? categoryId;
  final String? categoryName;
  final bool? allowsSale;
  final int? type;
  final bool? hasVariants;
  final double? basePrice;
  final int? conversionValue;
  final bool? isActive;
  final bool? isLotSerialControl;
  final bool? isBatchExpireControl;
  final List<String>? images;

  const ItemModel({
    this.createdDate,
    this.id,
    this.retailerId,
    this.code,
    this.name,
    this.fullName,
    this.categoryId,
    this.categoryName,
    this.allowsSale,
    this.type,
    this.hasVariants,
    this.basePrice,
    this.conversionValue,
    this.isActive,
    this.isLotSerialControl,
    this.isBatchExpireControl,
    this.images,
  });

  ItemModel copyWith({
    String? createdDate,
    int? id,
    int? retailerId,
    String? code,
    String? name,
    String? fullName,
    int? categoryId,
    String? categoryName,
    bool? allowsSale,
    int? type,
    bool? hasVariants,
    double? basePrice,
    int? conversionValue,
    bool? isActive,
    bool? isLotSerialControl,
    bool? isBatchExpireControl,
    List<String>? images,
  }) {
    return ItemModel(
      createdDate: createdDate ?? this.createdDate,
      id: id ?? this.id,
      retailerId: retailerId ?? this.retailerId,
      code: code ?? this.code,
      name: name ?? this.name,
      fullName: fullName ?? this.fullName,
      categoryId: categoryId ?? this.categoryId,
      categoryName: categoryName ?? this.categoryName,
      allowsSale: allowsSale ?? this.allowsSale,
      type: type ?? this.type,
      hasVariants: hasVariants ?? this.hasVariants,
      basePrice: basePrice ?? this.basePrice,
      conversionValue: conversionValue ?? this.conversionValue,
      isActive: isActive ?? this.isActive,
      isLotSerialControl: isLotSerialControl ?? this.isLotSerialControl,
      isBatchExpireControl: isBatchExpireControl ?? this.isBatchExpireControl,
      images: images ?? this.images,
    );
  }

  factory ItemModel.fromJson(Map<String, dynamic> json) {
    try {
      final itemModel = ItemModel(
        createdDate: json['createdDate'],
        id: json['id'],
        retailerId: json['retailerId'],
        code: json['code'],
        name: json['name'],
        fullName: json['fullName'],
        categoryId: json['categoryId'],
        categoryName: json['categoryName'],
        allowsSale: json['allowsSale'],
        type: json['type'],
        hasVariants: json['hasVariants'],
        basePrice: json['basePrice']+0.0,
        conversionValue: json['conversionValue'],
        isActive: json['isActive'],
        isLotSerialControl: json['isLotSerialControl'],
        isBatchExpireControl: json['isBatchExpireControl'],
        images:
            json.containsKey('images') ? json['images']?.cast<String>() : null,
      );
      return itemModel;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }
    throw 'Wrong data null';
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    try {
      data['createdDate'] = createdDate;
      data['id'] = id;
      data['retailerId'] = retailerId;
      data['code'] = code;
      data['name'] = name;
      data['fullName'] = fullName;
      data['categoryId'] = categoryId;
      data['categoryName'] = categoryName;
      data['allowsSale'] = allowsSale;
      data['type'] = type;
      data['hasVariants'] = hasVariants;
      data['basePrice'] = basePrice;
      data['conversionValue'] = conversionValue;
      data['isActive'] = isActive;
      data['isLotSerialControl'] = isLotSerialControl;
      data['isBatchExpireControl'] = isBatchExpireControl;
      data['images'] = images;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }

    return data;
  }

  @override
  List<Object?> get props => [
        createdDate,
        id,
        retailerId,
        code,
        name,
        fullName,
        categoryId,
        categoryName,
        allowsSale,
        type,
        hasVariants,
        basePrice,
        conversionValue,
        isActive,
        isLotSerialControl,
        isBatchExpireControl,
        images,
      ];
}
