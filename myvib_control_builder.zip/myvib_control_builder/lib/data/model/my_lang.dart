
import 'package:equatable/equatable.dart';

import '../../utils/log_utils.dart';

class MyLanguage extends Equatable {
  final String? code;
  final String? name;
  final String? icon;
  final bool? defaultValue;

  MyLanguage({
    this.code,
    this.name,
    this.icon,
    this.defaultValue,
  });

  MyLanguage copyWith({
    String? code,
    String? name,
    String? icon,
    bool? defaultValue,
  }) {
    return MyLanguage(
      code: code ?? this.code,
      name: name ?? this.name,
      icon: icon ?? this.icon,
      defaultValue: defaultValue ?? this.defaultValue,
    );
  }

  factory MyLanguage.fromJson(Map<String, dynamic> json) {
    try {
      final languages = MyLanguage(
        code: json['code'],
        name: json['name'],
        icon: json['icon'],
        defaultValue: json['default'],
      );
      return languages;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }
    throw 'Data null';
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    try {
      data['code'] = code;
      data['name'] = name;
      data['icon'] = icon;
      data['default'] = defaultValue;
    } catch (e, stacktrace) {
      LogUtils.d(e, stacktrace: stacktrace.toString());
    }

    return data;
  }

  @override
  List<Object?> get props => [
    code,
    name,
    icon,
    defaultValue,
  ];
}