class Language {
  String? name;
  String? code;
  String? countryCode;
  String? image;

  Language({
    this.name,
    this.code,
    this.image,
    this.countryCode,
  });

  Language.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    code = json['code'];
    countryCode = json['country_code'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['name'] = name;
    data['code'] = code;
    data['countryCode'] = countryCode;
    data['image'] = image;
    return data;
  }
}
