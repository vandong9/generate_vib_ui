import 'package:flutter/cupertino.dart';

import 'app.dart';
import 'ui/home/home_page.dart';
import 'ui/intro/intro_page.dart';
import 'ui/lang/lang_screen.dart';
import 'ui/legalandpolicy/legal_policy_page.dart';
import 'ui/login/login_page.dart';
import 'ui/register/register_page.dart';
import 'ui/splash/splash_page.dart';

class MyCustomRoute<Object> extends CupertinoPageRoute<Object> {
  MyCustomRoute({required WidgetBuilder builder, RouteSettings? settings})
      : super(builder: builder, settings: settings);

  @override
  Widget buildContent(BuildContext context) {
    return super.buildContent(context);
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    Application.currentContext = context;

    // final transit = max(1 - animation.value * 1.5, 0.0);
    // return FractionalTranslation(translation: Offset(transit, 0), child: child);
    return super
        .buildTransitions(context, animation, secondaryAnimation, child);
  }

  @override
  Widget buildPage(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation) {
    return super.buildPage(context, animation, secondaryAnimation);
  }

  @override
  bool canTransitionFrom(TransitionRoute previousRoute) {
    return super.canTransitionFrom(previousRoute);
  }
}

class FadeRoute extends PageRouteBuilder {
  final Widget page;

  FadeRoute({
    required this.page,
  }) : super(
          pageBuilder: (
            BuildContext context,
            Animation<double> animation,
            Animation<double> secondaryAnimation,
          ) =>
              page,
          transitionsBuilder: (
            BuildContext context,
            Animation<double> animation,
            Animation<double> secondaryAnimation,
            Widget child,
          ) =>
              FadeTransition(
            opacity: animation,
            child: child,
          ),
        );
}

RouteFactory get myRoute => (RouteSettings settings) {
      switch (settings.name) {
        case SplashScreen.routeName:
          return MyCustomRoute<Object>(
            builder: (_) => const SplashScreen(),
            settings: settings,
          );
        case IntroScreen.routeName:
          return MyCustomRoute<Object>(
            builder: (_) => const IntroScreen(),
            settings: settings,
          );
        case HomeScreen.routeName:
          return MyCustomRoute<Object>(
            builder: (_) => const HomeScreen(),
            settings: settings,
          );
        case LangScreen.routeName:
          return MyCustomRoute<Object>(
            builder: (_) => const LangScreen(),
            settings: settings,
          );
        case LoginScreen.routeName:
          return MyCustomRoute<Object>(
            builder: (_) => const LoginScreen(),
            settings: settings,
          );
        case RegisterScreen.routeName:
          final dataArg = (settings.arguments ?? {}) as Map;
          return MyCustomRoute<Object>(
            builder: (_) => RegisterScreen(
              data: dataArg,
            ),
            settings: settings,
          );

        case LegalPolicyPage.routeName:
          final dataArg = (settings.arguments ?? {}) as Map;
          return MyCustomRoute<Object>(
            builder: (_) => LegalPolicyPage(
              data: dataArg,
            ),
            settings: settings,
          );
        default:
          return MyCustomRoute<Object>(
            builder: (_) => SplashScreen(),
            settings: settings,
          );
      }
    };
