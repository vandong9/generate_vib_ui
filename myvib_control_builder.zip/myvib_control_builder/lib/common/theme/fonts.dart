part of 'theme.dart';

class Fonts {
  static const Poppins_Black = 'Poppins_Black';
  static const Poppins_Bold = 'Poppins_Bold';
  static const Poppins_Light = 'Poppins_Light';
  static const Poppins_Regular = 'Poppins_Regular';
  static const Poppins_Medium = 'Poppins_Medium';
  static const Poppins_ExtraBold = 'Poppins_ExtraBold';
  static const Poppins_SemiBold = 'Poppins_SemiBold';
  static const Helvetica = 'Helvetica';
}
