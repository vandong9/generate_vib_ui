part of 'theme.dart';

class ThemeColor {
  static const Color transparent = Colors.transparent;
  static const Color whiteColor = Colors.white;
  static const Color blackColor = Colors.black;
  static const Color primaryColor = Color(0xffffffff);
  static const Color primaryColorLight = Color(0xff53bdfc);
  static const Color primaryColorDay= Color(0xffc5e9fd);
  static const Color backgroundCellWeekPressed = Color(0xffc5e9fd);
  static const Color backgroundCellWeekNormal = Color(0xfff3f5f9);
  static const Color accentColor = Color(0xffD81B60);
  static const Color lightGrey = Color(0xFFF4F4F4);
  static const Color gray1 = Color(0xFFEEEEEE);
  static const Color gray2 = Color(0xFFDDDDDD);
  static const Color gray3 = Color(0xffB0B5C8);
  static const Color bgServices = Color(0xFFf3f3f6);
  static const Color darkGray1 = Color(0xFF7E7E7E);
  static const Color licFooter = Color(0xFF999999);
  static const Color blackFont = Color(0xFF444444);
  static const Color borderQRCODE = Color(0xFF00f900);
  static const Color bgInputField = Color(0xFFF1F1F5);
  static const Color bgBusinessMenu = Color(0xFFf5f5f5);
  static const Color bgBtnHome = Color(0xFFf4f5f7);
  static const Color placeHolderTextColor = Color(0xFFBABBBF);
  static const Color borderInputField = Color(0xFFCACBCB);
  static const Color borderMenu = Color(0xFFcccccc);
  static const Color coral = Color(0xFFEC6A65);
  static const Color seaForm = Color(0xFF5CC3D3);
  static const Color orange = Color(0xFFF09835);
  static const Color green = Color(0xFF7DC78A);
  static const Color purple = Color(0xFF8982F7);
  static const Color navy = Color(0xFF1955AF);
  static const Color grey = Color(0xFF8D8D9A);
  static const Color skyBlue = Color(0xFF8982F7);
  static const Color iceBurg = Color(0xFFE4E9F6);
  static const Color hotPink = Color(0xFFFF0977);
  static const Color coolBlue = Color(0xFF0797FF);

  static const Color cream_brulee = Color(0xFFFFE39F);
  static const Color scorpion = Color(0xFF565656);
  static const Color tundora = Color(0xFF444444);
  static const Color mine_shaft = Color(0xFF393838);
  static const Color shark = Color(0xff2A2A2C);

  ///Appointment Calendar View
  static const Color dividerTimeLine = Color(0xFFe2e2e3);
  static const Color cellBackground = Color(0xFFfbfbfd);
}
