part of 'theme.dart';

const sizeIcon = 3.0;
const sizeIconDouble = 6.0;
const sizeVerySmall = 5.0;
const sizeVerySmallx = 7.0;

const sizeSmall = 10.0;
const sizeSmallx = 12.0;
const sizeSmallxx = 14.0;
const sizeSmallxxx = 16.0;
const sizeSmallxxxx = 18.0;

const sizeNormal = 20.0;
const sizeNormalx = 25.0;
const sizeNormalxx = 30.0;
const sizeNormalxxx = 35.0;

const sizeLarge = 40.0;
const sizeLargex = 45.0;
const sizeLargexx = 50.0;
const sizeLargexxx = 60.0;

const sizeExLarge = 80.0;
const sizeExLargex = 85.0;
const sizeExLargexx = 90.0;
const sizeExLargexxx = 95.0;

const sizeImageSmall = 100.0;

const sizeImageNormal = 120.0;
const sizeImageNormalx = 140.0;
const sizeImageNormalxx = 160.0;
const sizeImageNormalxxx = 200.0;
const sizeImageNormalxxxx = 260.0;

const sizeImageLarge = 240.0;
const sizeImageLargex = 280.0;
const sizeImageLargexx = 320.0;
const sizeImageLargexxx = 360.0;
const sizeImageLargexxxx = 400.0;

const sizeImageSLarge= 600.0;
