import 'dart:ui';

import 'package:flutter/material.dart';

part 'fonts.dart';
part 'my_size.dart';
part 'text_style.dart';
part 'theme_color.dart';
part 'theme_data.dart';
part 'theme_decoration.dart';

