part of 'theme.dart';

class MyFontFamily {
  static const String SVNMillerBanner = "SVNMillerBanner";
  static const String Helvetica = "Helvetica";
}

class MyFontWeight {
  static const FontWeight black = FontWeight.w900;
  static const FontWeight extraLight = FontWeight.w200;
  static const FontWeight light = FontWeight.w300;
  static const FontWeight medium = FontWeight.w500;
  static const FontWeight regular = FontWeight.w400;
  static const FontWeight semiBold = FontWeight.w600;
  static const FontWeight bold = FontWeight.w700;
  static const FontWeight extraBold = FontWeight.w800;
}

const TextStyle textVerySmallx = TextStyle(
  color: Colors.black,
  fontSize: 7,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textSmall = TextStyle(
  color: Colors.black,
  fontSize: 10,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textSmall_Plus = TextStyle(
  color: Colors.black,
  fontSize: 11,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);

const TextStyle textSmallx = TextStyle(
  color: Colors.black,
  fontSize: 12,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textSmallxx = TextStyle(
  color: Colors.black,
  fontSize: 14,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textSmallxxx = TextStyle(
  color: Colors.black,
  fontSize: 16,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);

const TextStyle textNormal = TextStyle(
  color: Colors.black,
  fontSize: 18,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textNormalx = TextStyle(
  color: Colors.black,
  fontSize: 20,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textNormalxx = TextStyle(
  color: Colors.black,
  fontSize: 22,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textNormalxxx = TextStyle(
  color: Colors.black,
  fontSize: 24,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textNormalxxxx = TextStyle(
  color: Colors.black,
  fontSize: 26,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);

const TextStyle textLarge = TextStyle(
  color: Colors.black,
  fontSize: 30,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textLargex = TextStyle(
  color: Colors.black,
  fontSize: 32,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textLargexx = TextStyle(
  color: Colors.black,
  fontSize: 34,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textLargexxx = TextStyle(
  color: Colors.black,
  fontSize: 36,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textLargexxxx = TextStyle(
  color: Colors.black,
  fontSize: 40,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textLargexxxxx = TextStyle(
  color: Colors.black,
  fontSize: 45,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);

const TextStyle textExLarge = TextStyle(
  color: Colors.black,
  fontSize: 50,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textExLargex = TextStyle(
  color: Colors.black,
  fontSize: 54,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textExLargexx = TextStyle(
  color: Colors.black,
  fontSize: 58,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
const TextStyle textExLargexxx = TextStyle(
  color: Colors.black,
  fontSize: 62,
  fontFamily: MyFontFamily.SVNMillerBanner,
  decoration: TextDecoration.none,
);
