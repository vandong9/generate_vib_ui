part of 'theme.dart';

ThemeData defaultTheme() {
  return ThemeData(
    primaryColor: ThemeColor.primaryColor, colorScheme: ColorScheme.fromSwatch().copyWith(secondary: ThemeColor.accentColor),
  );
}
