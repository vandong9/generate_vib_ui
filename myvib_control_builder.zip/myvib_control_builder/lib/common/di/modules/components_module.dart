import 'package:hive_flutter/hive_flutter.dart';
import '../../../data/source/local/prefs/app_preferences.dart';
import '../../../data/source/local/prefs/app_preferences_impl.dart';
import '../../../utils/environment_info.dart';
import '../injection/injector.dart';

class ComponentsModule extends DIModule {
  @override
  Future<void> provides({EnvironmentInfo? env}) async {
    sl.registerLazySingleton<EnvironmentInfo>(() => env!);

    // final appDocDirectory = await getApplicationDocumentsDirectory();
    // final pathStored = '${appDocDirectory.path}';
    // await Directory(pathStored).create(recursive: true);
    //
    // ///Database
    // Hive.init(pathStored);
    await Hive.initFlutter();
    final box = await Hive.openBox('data');

    final AppPreferences appPreferences = AppPreferencesImpl(box: box);
    sl.registerLazySingleton(() => appPreferences);

    // final firebaseWrapper = FirebaseWrapper();
    // try {
    //   await firebaseWrapper.init();
    //   sl.registerLazySingleton<FirebaseWrapper>(() => firebaseWrapper);
    // } catch (e) {
    //   print('FirebaseWrapper :' + e.toString());
    // }
  }
}
