import 'package:connectivity_plus/connectivity_plus.dart';

import '../../../data/repository/config_repository.dart';
import '../../../data/repository/user_repository.dart';
import '../../../data/source/local/config_local_data_source.dart';
import '../../../data/source/local/user_local_data_source.dart';
import '../../../data/source/remote/config_remote_data_source.dart';
import '../../../data/source/remote/user_remote_data_source.dart';
import '../../../utils/environment_info.dart';
import '../../../utils/network_info.dart';
import '../injection/injector.dart';

class RepositoryModule extends DIModule {
  @override
  Future<void> provides({EnvironmentInfo? env}) async {
    /// Repositories
    sl.registerLazySingleton<NetworkInfo>(
      () => NetworkInfoImpl(sl()),
    );
    sl.registerLazySingleton(() => Connectivity());

    /// Repositories - Remote
    sl.registerFactory<UserRemoteDataSource>(
      () => UserRemoteDataSourceImpl(),
    );
    sl.registerFactory<ConfigRemoteDataSource>(
      () => ConfigRemoteDataSourceImpl(),
    );

    /// Repositories - LocalData
    ///
    sl.registerFactory<UserLocalDataSource>(
      () => UserLocalDataSourceImpl(appPreferences: sl()),
    );
    sl.registerFactory<ConfigLocalDataSource>(
      () => ConfigLocalDataSourceImpl(appPreferences: sl()),
    );

    /// Repositories - Impl
    sl.registerFactory<UserRepository>(
        () => UserRepositoryImpl(remoteDataSource: sl(), localDataSrc: sl()));
    sl.registerFactory<ConfigRepository>(
        () => ConfigRepositoryImpl(remoteDataSource: sl(), localDataSrc: sl()));
  }
}
