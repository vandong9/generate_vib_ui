import 'package:floralpunk/ui/splash/bloc/splash_bloc.dart';

import '../../../ui/home/bloc/home_bloc.dart';
import '../../../ui/intro/bloc/intro_bloc.dart';
import '../../../ui/login/bloc/login_bloc.dart';
import '../../../ui/register/bloc/register_bloc.dart';
import '../../../utils/environment_info.dart';
import '../../widget/base/bloc/base_bloc.dart';
import '../injection/injector.dart';

class BlocModule extends DIModule {
  @override
  Future<void> provides({EnvironmentInfo? env}) async {
    sl.registerLazySingleton(() => BaseBloc(
          userRepository: sl(),
          configRepository: sl(),
        ));

    sl.registerFactory(() => SplashBloc(
          userRepository: sl(),
          configRepository: sl(),
        ));
    sl.registerFactory(() => HomeBloc(
          configRepository: sl(),
        ));
    sl.registerFactory(() => IntroBloc());
    sl.registerFactory(() => LoginBloc(
          userRepository: sl(),
        ));
    sl.registerFactory(() => RegisterBloc(
          userRepository: sl(),
        ));
  }
}
