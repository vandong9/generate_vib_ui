import 'package:dio/dio.dart';
import 'package:floralpunk/data/model/user_info.dart';
import 'package:floralpunk/data/source/api_end_point.dart';
import 'package:floralpunk/utils/log_utils.dart';
import 'package:flutter/foundation.dart';
import '../../../data/repository/user_repository.dart';
import '../../../utils/environment_info.dart';

import '../../widget/base/bloc/base_bloc.dart';
import '../injection/injector.dart';

class ApiModule extends DIModule {
  @override
  Future<void> provides({EnvironmentInfo? env}) async {
    final dio = Dio(BaseOptions());
    dio.options.connectTimeout = 180000.0; //180s
    dio.options.receiveTimeout = 180000.0;
    dio.interceptors.add(LogInterceptor(
        responseBody: !kReleaseMode, requestBody: !kReleaseMode));
    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (request, handler) {
          final userInfo = sl<UserRepository>().getCurrentUser();
          if (userInfo != null && (userInfo.accessToken?.isNotEmpty ?? false)) {
            request.headers['Authorization'] = 'Bearer ${userInfo.accessToken}';
          }
          return handler.next(request);
        },
        onError: (e, handler) async {
          if (e.response?.statusCode == CODE_UN_AUTH) {
            _handleMixError(e, handler, dio);
          } else if (e.response?.statusCode == CODE_BAD_REQUEST) {
            handler.reject(e);
          }
        },
      ),
    );
    sl.registerLazySingleton<Dio>(() => dio);
  }

  void _handleMixError(e, handler, Dio dio) async {
    try {
      final userInfo = sl<UserRepository>().getCurrentUser();
      await Dio().post(endPointRefreshToken, data: {
        {
          'refreshToken': userInfo?.refreshToken,
          'accessToken': userInfo?.accessToken
        }
      }).then((value) async {
        if (value.statusCode == CODE_SUCCESS) {
          final userIfo = UserInfo.fromJson(value.data);
          print('userIfo.accessToken');
          print(userIfo.accessToken);
          sl<UserRepository>().saveCurrentUser(userIfo);
          //set bearer
          e.requestOptions.headers["Authorization"] =
              "Bearer " + (userIfo.accessToken ?? '');

          print('Bearer');
          //create request with new access token
          final opts = Options(
              method: e.requestOptions.method,
              headers: e.requestOptions.headers);
          final cloneReq = await dio.request(e.requestOptions.path,
              options: opts,
              data: e.requestOptions.data,
              queryParameters: e.requestOptions.queryParameters);

          return handler.resolve(cloneReq);
        }
        handler.reject(e);
      }).onError((error, stackTrace) {
        //force Logout if cannot renew Token
        sl<BaseBloc>().add(Logout());

        handler.reject(e);
      });
    } catch (er, st) {
      LogUtils.d(er, stacktrace: st.toString());
    }
  }
}
