import 'package:get_it/get_it.dart';
import '../../../utils/environment_info.dart';

import '../modules/api_module.dart';
import '../modules/bloc_module.dart';
import '../modules/components_module.dart';
import '../modules/repository_module.dart';

final sl = GetIt.instance;

abstract class DIModule {
  void provides({EnvironmentInfo? env});
}

class Injection {
  static Future<void> inject(EnvironmentInfo env) async {
    await ComponentsModule().provides(env: env);
    await ApiModule().provides();
    await RepositoryModule().provides();
    await BlocModule().provides();
  }
}
