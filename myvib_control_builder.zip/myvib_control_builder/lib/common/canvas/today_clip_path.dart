import 'package:flutter/material.dart';
import '../theme/theme.dart';

class TodayClipPath extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    final halfWidth = size.width / 2;
    final halfHeight = size.height / 2;
    final arrowWidth = sizeVerySmall;
    path.lineTo(0, 0);
    path.lineTo(halfWidth, 0);
    path.lineTo(halfWidth, halfHeight - arrowWidth);
    path.lineTo(size.width, halfHeight);
    path.lineTo(halfWidth, halfHeight + arrowWidth);
    path.lineTo(halfWidth, size.height);
    path.lineTo(0, size.height);


    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    return false;
  }
}
