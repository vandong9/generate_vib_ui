import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../../theme/theme.dart';
import 'my_button.dart';

class MyButtonIcon extends StatelessWidget {
  final Widget child;

  final TextAlign textAlign;
  final TextStyle textStyle;
  final Function()? onTap;
  final bool disable;
  final Map<String, Color> buttonStyle;
  final bool isFillParent;
  final double paddingVertical;
  final double radius;
  final double paddingHorizontal;
  final double height;
  final double minWidth;
  final bool isOutline;

  const MyButtonIcon({
    key,
    required this.child,
    this.isOutline = false,
    this.textStyle = textSmallxxx,
    this.radius = sizeSmallxx,
    this.buttonStyle = styleButtonColor_1,
    this.textAlign = TextAlign.center,
    this.paddingVertical = sizeSmallx,
    this.paddingHorizontal = sizeNormalx,
    this.onTap,
    this.height = sizeLargexx,
    this.minWidth = 0,
    this.disable = false,
    this.isFillParent = false,
  });

  @override
  Widget build(BuildContext context) {
    final onTapButton = !disable ? onTap : null;
    final style = buttonStyle;

    return isOutline
        ? OutlinedButton(
            style: OutlinedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0),
              ),
              side: const BorderSide(color: Colors.black, width: 2),
              padding: EdgeInsets.fromLTRB(paddingHorizontal, paddingVertical,
                  paddingHorizontal, paddingVertical),
              primary: style['color'],
            ),
            onPressed: onTapButton,
            // splashColor: rippleColor.withOpacity(0.5),
            // highlightColor: rippleColor.withOpacity(0.1),
            child: child,
          )
        : MaterialButton(
            color: style['color'],
            hoverColor: style['hoverColor'],
            splashColor: style['splashColor'],
            highlightColor: style['highlightColor'],
            disabledColor: style['disabledColor'],
            elevation: 0,
            hoverElevation: 0,
            focusElevation: 0,
            highlightElevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(radius),
            ),
            padding: EdgeInsets.fromLTRB(paddingHorizontal, paddingVertical,
                paddingHorizontal, paddingVertical),
            onPressed: onTapButton,
            height: height,
            minWidth: minWidth,
            child: child,
          );
  }
}
