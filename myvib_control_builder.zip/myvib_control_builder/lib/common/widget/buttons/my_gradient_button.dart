import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../../theme/theme.dart';

class MyGradientButton extends StatelessWidget {
  final String? text;

  final TextAlign textAlign;
  final TextStyle textStyle;
  final Function()? onTap;
  final bool disable;
  final bool isFillParent;
  final double paddingVertical;
  final double paddingHorizontal;
  final double height;
  final double minWidth;

  MyGradientButton({
    key,
    this.text,
    this.textStyle = textSmallxxx,
    this.textAlign = TextAlign.center,
    this.paddingVertical = sizeSmallx,
    this.paddingHorizontal = sizeNormalx,
    this.onTap,
    this.height = sizeLargexx,
    this.minWidth = 0,
    this.disable = false,
    this.isFillParent = false,
  });

  @override
  Widget build(BuildContext context) {
    final onTapButton = !disable ? onTap : null;
    return Container(
      height: sizeLargexx,
      constraints: BoxConstraints(minWidth: minWidth),
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(sizeNormalx)),
        gradient: LinearGradient(
          colors: <Color>[
            Color(0xffeadbb6),
            Color(0xff8d7e58),
          ],
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(sizeNormalx),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            radius: sizeNormalx,
            splashColor: Colors.white,
            onTap: onTapButton,
            child: Row(
              mainAxisSize: isFillParent ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  text??'',
                  textAlign: textAlign,
                  style: textStyle,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
//  StadiumBorder(), circle
}
