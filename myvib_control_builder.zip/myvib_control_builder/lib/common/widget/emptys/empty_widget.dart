import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/ui_util.dart';
import '../../constants/constants.dart';
import '../../theme/theme.dart';

class EmptyState extends StatelessWidget {
  final String? content;

  const EmptyState({Key? key, this.content}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          UIUtil.makeImageWidget(
            Res.ic_empty,
            height: 100,
            width: 100,
          ),
          const SizedBox(
            height: sizeSmall,
          ),
          Text(
            content ?? Lang.common_no_data.tr(),
            style: textNormal.copyWith(
              color: ThemeColor.licFooter,
              fontWeight: FontWeight.w700,
            ),
          )
        ],
      ),
    );
  }
}
