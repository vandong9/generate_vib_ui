import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../constants/constants.dart';
import '../../theme/theme.dart';

class HeaderLogo extends StatelessWidget {
  final bool haveMenu;
  final bool haveBack;
  final String? title;

  final Function? onClickBack;
  final Function? onClickMenu;

  const HeaderLogo({
    Key? key,
    this.haveMenu = false,
    this.title,
    this.haveBack = false,
    this.onClickBack,
    this.onClickMenu,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final data = MediaQuery.of(context);
    final padding = data.padding;

    return Container(
      padding: EdgeInsets.only(
        top: padding.top,
        left: sizeVerySmall,
        right: sizeVerySmall,
      ),
      width: double.infinity,
      color: ThemeColor.primaryColor,
      child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
        final logoWidth = constraints.maxWidth * 0.8;
        return Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            haveMenu
                ? Align(
                    alignment: Alignment.topLeft,
                    child: Material(
                      color: Colors.transparent,
                      child: IconButton(
                          onPressed: () {
                            if (onClickMenu != null) {
                              onClickMenu!();
                            }
                          },
                          splashRadius: sizeNormalx,
                          splashColor: ThemeColor.whiteColor,
                          padding: const EdgeInsets.all(sizeSmall),
                          iconSize: sizeNormalx,
                          icon: SvgPicture.asset(
                            Res.intro_image,
                          )),
                    ),
                  )
                : const SizedBox(
                    height: sizeLargexx,
                  ),
            SvgPicture.asset(
              Res.intro_image,
              width: logoWidth,
              fit: BoxFit.cover,
              color: Colors.white,
            ),
            Stack(
              children: [
                haveBack
                    ? Align(
                        alignment: Alignment.bottomLeft,
                        child: Material(
                          color: Colors.transparent,
                          child: IconButton(
                              onPressed: () {
                                if (onClickBack != null) {
                                  onClickBack!();
                                }
                              },
                              splashRadius: sizeNormal,
                              padding: const EdgeInsets.all(sizeSmall),
                              splashColor: ThemeColor.whiteColor,
                              icon: const Icon(
                                Icons.arrow_back_ios_outlined,
                                color: ThemeColor.whiteColor,
                              )),
                        ),
                      )
                    : const SizedBox(
                        height: sizeLargexx,
                      ),
                title != null
                    ? Align(
                        alignment: Alignment.center,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: sizeNormal,
                          ),
                          child: Text(
                            title ?? '',
                            style: textNormalxxx.copyWith(
                              color: ThemeColor.whiteColor,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ))
                    : const SizedBox(),
              ],
            )
          ],
        );
      }),
    );
  }
}
