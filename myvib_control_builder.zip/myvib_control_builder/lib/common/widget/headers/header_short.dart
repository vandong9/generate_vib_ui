import 'package:flutter/material.dart';

import '../../theme/theme.dart';

class HeaderShort extends StatelessWidget {
  final String? title;
  final Widget? menuAction;
  final Function? onClickBack;

  const HeaderShort({
    Key? key,
    this.title,
    this.menuAction,
    this.onClickBack,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final data = MediaQuery.of(context);
    final padding = data.padding;

    return Container(
      padding: EdgeInsets.only(
        top: padding.top + sizeSmallxxx,
        bottom: sizeSmallxxx,
        left: sizeVerySmall,
        right: sizeVerySmall,
      ),
      width: double.infinity,
      color: ThemeColor.primaryColor,
      child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
        return Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Material(
                    color: Colors.transparent,
                    child: IconButton(
                        onPressed: () {
                          if (onClickBack != null) {
                            onClickBack!();
                          }
                        },
                        splashRadius: sizeNormal,
                        padding: const EdgeInsets.all(sizeSmall),
                        splashColor: ThemeColor.whiteColor,
                        icon: const Icon(
                          Icons.arrow_back_ios_outlined,
                          color: ThemeColor.whiteColor,
                        )),
                  ),
                ),
                if (menuAction != null)
                  Align(
                    alignment: Alignment.centerRight,
                    child: menuAction,
                  ),
                title != null
                    ? Align(
                        alignment: Alignment.topCenter,
                        child: Text(
                          title ?? '',
                          style: textNormalxxx.copyWith(
                            color: ThemeColor.whiteColor,
                            fontWeight: FontWeight.w400,
                          ),
                        ))
                    : const SizedBox(),
              ],
            )
          ],
        );
      }),
    );
  }
}
