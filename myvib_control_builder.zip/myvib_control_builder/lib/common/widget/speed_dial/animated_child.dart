import 'package:flutter/material.dart';

import '../../theme/theme.dart';

class AnimatedChild extends AnimatedWidget {
  final int? index;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double? elevation;
  final Widget? child;
  final String? label;
  final TextStyle? labelStyle;
  final Color? labelBackgroundColor;
  final Widget? labelWidget;
  final bool visible;
  final VoidCallback? onTap;
  final VoidCallback? toggleChildren;
  final ShapeBorder? shape;
  final String? heroTag;

  AnimatedChild({
    Key? key,
    required Animation<double> animation,
    this.index,
    this.backgroundColor,
    this.foregroundColor,
    this.elevation = 6.0,
    this.child,
    this.label,
    this.labelStyle,
    this.labelBackgroundColor,
    this.labelWidget,
    this.visible = false,
    this.onTap,
    this.toggleChildren,
    this.shape,
    this.heroTag,
  }) : super(key: key, listenable: animation);

  Widget buildLabel() {
    final animation = listenable as Animation<double>;

    if (!((label != null || labelWidget != null) &&
        visible &&
        animation.value == 40.0)) {
      return Container();
    }

    if (labelWidget != null) {
      return labelWidget!;
    }

    return GestureDetector(
      onTap: _performAction,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 8.0),
        margin: const EdgeInsets.only(right: 16.0),
        child: Text(label ?? '', style: labelStyle),
      ),
    );
  }

  void _performAction() {
    if (onTap != null) {
      onTap!();
    }
    toggleChildren!();
  }

  @override
  Widget build(BuildContext context) {
    final animation = listenable as Animation<double>;

    final Widget buttonChild = animation.value > 30
        ? Container(
            width: animation.value,
            height: animation.value,
            child: child ?? Container(),
          )
        : Container(
            width: 0.0,
            height: 0.0,
          );

    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          buildLabel(),
          Container(
            width: 40.0,
            height: animation.value,
            padding: EdgeInsets.only(bottom: 40.0 - animation.value),
            margin: EdgeInsets.only(
              right: sizeNormal * (animation.value / 40),
              top: sizeVerySmall * (animation.value / 40),
              bottom: sizeVerySmall * (animation.value / 40),
              left: sizeVerySmall * (animation.value / 40),
            ),
            child: Container(
              height: 40.0,
              width: animation.value,
              padding: const EdgeInsets.only(top: 0, bottom: 0),
              child: FloatingActionButton(
                heroTag: heroTag,
                onPressed: _performAction,
                backgroundColor: backgroundColor,
                foregroundColor: foregroundColor,
                elevation: elevation,
                child: buttonChild,
              ),
            ),
          )
        ],
      ),
    );
  }
}
