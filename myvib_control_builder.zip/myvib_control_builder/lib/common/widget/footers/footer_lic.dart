import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../constants/constants.dart';
import '../../theme/theme.dart';

class FooterLic extends StatelessWidget {
  final Color textColor;
  final bool isNoPadding;

  const FooterLic({
    Key? key,
    required this.textColor,
    this.isNoPadding = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final data = MediaQuery.of(context);
    final padding = data.padding;

    return Container(
      padding: EdgeInsets.only(
        bottom: isNoPadding ? 0 : padding.bottom + sizeSmall,
      ),
      child: Text(
        Lang.common_copy_right.tr(
          args: [DateTime.now().year.toString()],
        ),
        textAlign: TextAlign.center,
        style: textSmall_Plus.copyWith(color: textColor),
      ),
    );
  }
}
