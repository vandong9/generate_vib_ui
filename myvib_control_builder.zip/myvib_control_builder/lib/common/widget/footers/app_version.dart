import 'package:flutter/material.dart';
import '../../../utils/string_util.dart';

import '../../theme/theme.dart';

class AppVersion extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final data = MediaQuery.of(context);
    final padding = data.padding;

    return Container(
      padding: EdgeInsets.only(
        bottom: padding.bottom + sizeSmall,
      ),
      child: FutureBuilder<String>(
          future: getAppVersionAndDate(), // async work
          builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
            switch (snapshot.connectionState) {
              case ConnectionState.waiting:
                return const Text('....');
              default:
                if (snapshot.hasError) {
                  return const Text('V1.0.1@');
                } else {
                  return Text(
                    snapshot.data ?? '',
                    style: textSmallxx.copyWith(
                      color: ThemeColor.blackFont,
                    ),
                  );
                }
            }
          }),
    );
  }
}
