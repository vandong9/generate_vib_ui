part of 'base_bloc.dart';

@immutable
abstract class BaseBlocState {
  final UserInfo? userInfo;
  final ConfigModel? configModel;

  UserInfo get userData => userInfo ?? UserInfo();

  const BaseBlocState({
    this.userInfo,
    this.configModel,
  });
}

class BaseInitial extends BaseBlocState {
  const BaseInitial({
    UserInfo? userInfo,
    ConfigModel? configModel,
  }) : super(
          userInfo: userInfo,
          configModel: configModel,
        );
}

class UpdateProfile extends BaseBlocState {
  const UpdateProfile({
    UserInfo? userInfo,
    ConfigModel? configModel,
  }) : super(
          userInfo: userInfo,
          configModel: configModel,
        );
}

class LogoutState extends BaseBlocState {}
