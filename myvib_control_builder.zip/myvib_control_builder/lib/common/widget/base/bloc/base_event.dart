part of 'base_bloc.dart';

@immutable
abstract class BaseEvent {}

class Logout extends BaseEvent {}

class Init extends BaseEvent {}

class FetchUserProfile extends BaseEvent {}


class OnProfileChange extends BaseEvent {}
