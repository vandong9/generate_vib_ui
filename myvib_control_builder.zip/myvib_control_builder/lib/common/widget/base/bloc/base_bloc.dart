import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:floralpunk/data/model/config_model.dart';
import 'package:floralpunk/data/repository/config_repository.dart';
import 'package:meta/meta.dart';

import '../../../../data/model/user_info.dart';
import '../../../../data/repository/user_repository.dart';

part 'base_event.dart';

part 'base_state.dart';

class BaseBloc extends Bloc<BaseEvent, BaseBlocState> {
  final UserRepository userRepository;
  final ConfigRepository configRepository;

  BaseBloc({
    required this.userRepository,
    required this.configRepository,
  }) : super(BaseInitial(
          userInfo: userRepository.getCurrentUser(),
          configModel: configRepository.getConfig(),
        )) {
    on<BaseEvent>((event, emit) async {
      if (state is! LogoutState && event is Logout) {
        await userRepository.logout();
        emit.call(LogoutState());
      } else if (event is OnProfileChange) {
        emit.call(UpdateProfile(
          userInfo: userRepository.getCurrentUser(),
          configModel: configRepository.getConfig(),
        ));
      } else if (event is Init) {
        emit.call(BaseInitial(
          userInfo: userRepository.getCurrentUser(),
          configModel: configRepository.getConfig(),
        ));
      }
    });
  }
}
