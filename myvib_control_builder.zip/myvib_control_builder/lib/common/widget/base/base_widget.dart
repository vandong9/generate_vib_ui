import 'dart:async';
import 'dart:convert';

import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:floralpunk/ui/intro/intro_page.dart';
import 'package:floralpunk/ui/splash/splash_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../data/model/my_lang.dart';
import '../../../data/repository/user_repository.dart';
import '../../../data/source/api_end_point.dart';
import '../../../utils/navigate_util.dart';
import '../../constants/constants.dart';
import '../../di/injection/injector.dart';
import '../../dialog/progress_dialog.dart';
import '../loading/circle_loading.dart';
import 'bloc/base_bloc.dart';

class BaseWidget extends StatefulWidget {
  const BaseWidget({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return BaseState();
  }
}

class BaseState<T extends BaseWidget> extends State<T> {
  final _baseBloc = sl<BaseBloc>();
  StreamSubscription? streamSubscriptionBase;
  StreamSubscription? streamNotificationBase;
  ProgressDialog? pbLoading;

  void changeLang(MyLanguage? lang) {
    var code = '';
    var countryCode = '';

    switch (lang?.code ?? '') {
      case 'vi':
        code = lang?.code ?? '';
        countryCode = 'VN';
        break;
      case 'en':
        code = lang?.code ?? '';
        countryCode = 'US';
        break;

      default:
    }
    updateLangEndPoint(Locale(code, countryCode));
    // context.setLocale(Locale(code, countryCode));
  }

  void initDialogLoading(BuildContext context) {
    pbLoading = ProgressDialog(
      context,
      showLogs: true,
      isDismissible: false,
    );
    pbLoading?.style(
      message: Lang.common_please_wait.tr(),
      progressWidget: CircleLoading(),
    );
  }

  void lockPortrait() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return const SizedBox();
  }

  @override
  void initState() {
    super.initState();
    streamSubscriptionBase = _baseBloc.stream.listen((state) {
      //Do for Logout State
      if (state is LogoutState) {
        NavigateUtil.pop(context,
            routeName: IntroScreen.routeName, release: true);
      }
    });

    lockPortrait();
  }

  static bool checkDirectNotification(
      BuildContext context, RemoteMessage? message,
      {Map? body, String? action}) {
    final userRepository = sl<UserRepository>();
    final userInfo = userRepository.getCurrentUser();
    var currentRouteName = '';
    try {
      currentRouteName = ModalRoute.of(context)?.settings.name ?? '';
      if (message != null && message.data.isNotEmpty) {
        print('messsageData');
        print(message.data);
        body = {};
        if (message.data.containsKey('notificationData')) {
          body = json.decode(message.data['notificationData']);
        }
        action = message.data['action'] ?? '';
      }

      if (userInfo != null && (action?.isNotEmpty ?? false)) {
        print('action ' + (action?.toString() ?? ''));
        //Check Notification Action and  Direct user
        switch (action?.toUpperCase() ?? '') {}
        return true;
      }
    } catch (e) {
      print(e);
    }
    return false;
  }

  @override
  void dispose() {
    super.dispose();
    streamSubscriptionBase?.cancel();
    streamNotificationBase?.cancel();
  }

  void hideKeyboard() {}
}
