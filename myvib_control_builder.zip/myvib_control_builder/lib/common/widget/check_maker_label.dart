import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../constants/constants.dart';
import '../theme/theme.dart';

class CheckMarkerLabel extends StatelessWidget {
  final String title;

  const CheckMarkerLabel({
    Key? key,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return groupInfo(title);
  }

  Widget groupInfo(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: sizeVerySmall,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          SvgPicture.asset(
            Res.intro_image,
            color: ThemeColor.primaryColor,
            width: sizeNormal + 1,
          ),
          const SizedBox(
            width: sizeSmall,
          ),
          Text(
            title,
            style: textNormal.copyWith(
              color: ThemeColor.blackFont,
            ),
          )
        ],
      ),
    );
  }
}
