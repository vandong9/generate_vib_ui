import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../constants/constants.dart';
import '../theme/theme.dart';

class MyRefreshList extends StatelessWidget {
  final RefreshController? refreshController;
  final Function()? onRefresh;
  final Function()? onLoading;
  final Color textColorRefresh;
  final bool enablePullDown;
  final bool enablePullUp;
  final ScrollController? scrollController;
  final Axis scrollDirection;
  final Widget listView;
  final ScrollPhysics scrollPhysics;

  const MyRefreshList({
    Key? key,
    @required this.refreshController,
    this.onRefresh,
    this.enablePullDown = false,
    this.enablePullUp = false,
    this.scrollPhysics = const ScrollPhysics(),
    this.scrollDirection = Axis.vertical,
    this.textColorRefresh = ThemeColor.primaryColor,
    this.onLoading,
    required this.listView,
    this.scrollController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SmartRefresher(
      enablePullDown: enablePullDown,
      enablePullUp: enablePullUp,
      scrollDirection: scrollDirection,
      physics: scrollPhysics,
      scrollController: scrollController,
      header: const WaterDropHeader(),
      footer: CustomFooter(
        builder: (BuildContext context, LoadStatus? mode) {
          Widget body;
          if (mode == LoadStatus.idle) {
            body = Text(
              Lang.common_pull_to_load.tr(),
              style: textSmallxx.copyWith(color: textColorRefresh),
            );
          } else if (mode == LoadStatus.loading) {
            body = const CupertinoActivityIndicator();
          } else if (mode == LoadStatus.failed) {
            body = Text('Load Failed!Click retry!',
                style: textSmallxx.copyWith(color: textColorRefresh));
          } else if (mode == LoadStatus.canLoading) {
            body = Text(Lang.common_release_to_load_more.tr(),
                style: textSmallxx.copyWith(color: textColorRefresh));
          } else {
            body = Text(Lang.common_no_more_Data.tr(),
                style: textSmallxx.copyWith(color: textColorRefresh));
          }
          return Container(
            height: 55.0,
            child: Center(child: body),
          );
        },
      ),
      controller: refreshController ?? RefreshController(),
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: listView,
    );
  }
}
