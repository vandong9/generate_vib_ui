import 'dart:async';

import 'package:flutter/material.dart';

import '../constants/constants.dart';
import 'package:easy_localization/easy_localization.dart';
import '../theme/theme.dart';

class ResendWidget extends StatefulWidget {
  final Function() onResend;

  const ResendWidget({
    Key? key,
    required this.onResend,
  }) : super(key: key);

  @override
  State<ResendWidget> createState() => ResendWidgetState();
}

class ResendWidgetState extends State<ResendWidget> {
  Timer? _timer;
  bool isCounting = false;
  int totalTime = 30;

  void startTimer() {
    isCounting = true;
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(
      oneSec,
      (Timer timer) {
        if (totalTime == 0) {
          setState(() {
            isCounting = false;
            timer.cancel();
          });
        } else {
          setState(() {
            totalTime--;
          });
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (isCounting) {
          return;
        }
        widget.onResend();
      },
      child: Container(
        padding: const EdgeInsets.only(
          bottom: sizeIcon,
        ),
        decoration: const BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: ThemeColor.blackColor,
              width: 1,
            ),
          ),
        ),
        child: isCounting
            ? Text(
                Lang.register_resend_in.tr(
                  args: [
                    totalTime.toString(),
                  ],
                ),
                textAlign: TextAlign.center,
                style: textSmallxx.copyWith(
                  color: ThemeColor.blackFont,
                  fontFamily: MyFontFamily.Helvetica,
                  fontWeight: FontWeight.w300,
                ),
              )
            : Text(
                Lang.register_resend.tr(),
                textAlign: TextAlign.center,
                style: textSmallxx.copyWith(
                  color: ThemeColor.blackColor,
                  fontFamily: MyFontFamily.Helvetica,
                  fontWeight: FontWeight.w300,
                ),
              ),
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    isCounting = false;
    super.dispose();
  }
}
