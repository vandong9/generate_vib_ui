import 'package:flutter/material.dart';
import '../theme/theme.dart';

class CircleMarkerLabel extends StatelessWidget {
  final String title;

  const CircleMarkerLabel({
    Key? key,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return groupInfoLearnMore(title);
  }

  Widget groupInfoLearnMore(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: sizeVerySmall,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.only(
              top: sizeVerySmall,
            ),
            child: Icon(
              Icons.circle,
              color: ThemeColor.primaryColor,
              size: sizeSmall,
            ),
          ),
          const SizedBox(
            width: sizeSmall,
          ),
          Flexible(
            child: Text(
              title,
              style: textSmallxxx.copyWith(
                color: ThemeColor.blackFont,
              ),
            ),
          )
        ],
      ),
    );
  }
}
