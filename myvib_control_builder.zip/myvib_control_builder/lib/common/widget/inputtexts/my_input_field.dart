import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import '../../theme/theme.dart';

class MyInputField extends StatefulWidget {
  final FocusNode? focusNode;
  final String? errorMessage;
  final FocusNode? nextFocusNode;
  final bool obscureText;
  final TextInputAction textInputAction;
  final AutovalidateMode? autoValidateMode;
  final String? textHint;
  final bool nonStyle;
  final int? maxLen;
  final double horizontalPadding;
  final TextInputType keyboardType;
  final TextCapitalization textCapitalization;
  final Function(String)? onFieldSubmitted;
  final Function(String)? onChanged;
  final bool isEnable;
  final TextStyle textStyle;
  final TextEditingController? textController;
  final bool? usePhoneFormat;

  const MyInputField(
      {Key? key,
      this.focusNode,
      this.obscureText = false,
      this.nonStyle = true,
      this.isEnable = true,
      this.usePhoneFormat = true,
      this.maxLen,
      this.nextFocusNode,
      this.textCapitalization = TextCapitalization.none,
      this.horizontalPadding = sizeNormal,
      this.textStyle = textNormalx,
      this.textController,
      this.keyboardType = TextInputType.text,
      this.errorMessage,
      this.autoValidateMode,
      this.textHint,
      this.onChanged,
      this.onFieldSubmitted,
      this.textInputAction = TextInputAction.next})
      : super(key: key);

  @override
  _MyInputFieldState createState() => _MyInputFieldState();
}

class _MyInputFieldState extends State<MyInputField> {
  // ignore: type_annotate_public_apis, prefer_typing_uninitialized_variables
  var formatText;

  @override
  void initState() {
    super.initState();
    if (widget.usePhoneFormat ?? false) {
      formatText = TextInputType.phone == widget.keyboardType
          ? [
              MaskTextInputFormatter(
                  mask: '(###) ###-####', filter: {'#': RegExp(r'[0-9]')})
            ]
          : (TextInputType.phone == widget.keyboardType
              ? [
                  FilteringTextInputFormatter.allow(
                      RegExp('([0-9]+(\.[0-9]+)?)'))
                ]
              : null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      decoration: const BoxDecoration(
          border: Border(
              bottom: BorderSide(
        color: ThemeColor.blackColor,
        width: 1,
      ))),
      child: TextFormField(
        focusNode: widget.focusNode,
        textAlignVertical: TextAlignVertical.center,
        obscureText: widget.obscureText,
        textCapitalization: widget.textCapitalization,
        onChanged: widget.onChanged,
        inputFormatters: formatText,
        maxLength: widget.maxLen,
        enabled: widget.isEnable,
        autovalidateMode: widget.autoValidateMode ?? AutovalidateMode.disabled,
        style: widget.textStyle.copyWith(
          color: ThemeColor.blackFont,
          fontWeight: FontWeight.w300,
        ),
        decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(
            horizontal: widget.horizontalPadding,
            vertical: sizeSmall,
          ),
          border: InputBorder.none,
          isCollapsed: true,
          isDense: true,
          counter: null,
          focusedBorder: InputBorder.none,
          floatingLabelBehavior: FloatingLabelBehavior.never,
          enabledBorder: InputBorder.none,
          counterText: '',
          errorBorder: InputBorder.none,
          disabledBorder: InputBorder.none,
          labelText: widget.textHint,
          labelStyle: widget.textStyle.copyWith(
            color: ThemeColor.placeHolderTextColor,
          ),
        ),
        textInputAction: widget.textInputAction,
        keyboardType: widget.keyboardType,
        controller: widget.textController,
        onFieldSubmitted: (v) {
          if (widget.nextFocusNode != null) {
            FocusScope.of(context).requestFocus(widget.nextFocusNode);
          }
          if (widget.onFieldSubmitted != null) {
            widget.onFieldSubmitted!(v);
          }
        },
      ),
    );
  }
}
