import 'package:floralpunk/common/theme/theme.dart';
import 'package:flutter/material.dart';

class OtpInput extends StatelessWidget {
  final TextEditingController controller;
  final bool autoFocus;
  final FocusNode focusNode;
  final FocusNode? nextFocusNode;
  final FocusNode? previousFocusNode;
  final double width;
  final double height;
  final Function()? submitOtp;

  const OtpInput(
    this.controller,
    this.autoFocus, {
    Key? key,
    required this.focusNode,
    required this.nextFocusNode,
    required this.previousFocusNode,
    required this.width,
    this.submitOtp,
    required this.height,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
      child: TextField(
        autofocus: autoFocus,
        focusNode: focusNode,
        textAlign: TextAlign.center,
        keyboardType: TextInputType.number,
        controller: controller,
        style: textNormalx.copyWith(
          fontFamily: MyFontFamily.Helvetica,
          fontWeight: FontWeight.w300,
        ),
        maxLength: 1,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderSide: const BorderSide(
              width: 1,
            ),
            borderRadius: BorderRadius.circular(0),
          ),
          counterText: '',
          hintStyle: textNormalx.copyWith(
            fontFamily: MyFontFamily.Helvetica,
            fontWeight: FontWeight.w300,
          ),
        ),
        onChanged: (value) {
          if (value.length == 1) {
            // nextFocusNode?.requestFocus();
            FocusScope.of(context).nextFocus();
            if (submitOtp != null) {
              submitOtp!();
            }
          } else {
            previousFocusNode?.requestFocus();
          }
        },
      ),
    );
  }
}
