
import 'package:flutter/material.dart';


class DrawerMenu extends StatefulWidget {
  final Function? onSignOut;
  final Function? closeMenu;

  const DrawerMenu({
    this.onSignOut,
    this.closeMenu,
  });

  @override
  _DrawerMenuState createState() => _DrawerMenuState();
}

class _DrawerMenuState extends State<DrawerMenu> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SizedBox(),
    );
  }

}
