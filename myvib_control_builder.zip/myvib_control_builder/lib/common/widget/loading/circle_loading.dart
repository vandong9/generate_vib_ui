import 'package:flutter/material.dart';
import '../../theme/theme.dart';

class CircleLoading extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        height: sizeNormalxx,
        width: sizeNormalxx,
        child: const CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation(
            ThemeColor.primaryColor,
          ),
        ),
      ),
    );
  }
}
