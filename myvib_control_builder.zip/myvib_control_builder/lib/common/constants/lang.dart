part of 'constants.dart';

class Lang {
  static const common_no_data = 'common.no_data';
  static const common_please_wait = 'common.please_wait';
  static const common_refresh_completed = 'common.refresh_completed';
  static const common_release_to_load_more = 'common.release_to_load_more';
  static const common_no_more_Data = 'common.no_more_Data';
  static const common_pull_to_load = 'common.pull_to_load';
  static const common_copy_right = 'common.copy_right';
  static const common_learn_more = 'common.learn_more';
  static const common_yes = 'common.yes';
  static const common_no = 'common.no';
  static const common_monday = 'common.monday';
  static const common_tuesday = 'common.tuesday';
  static const common_wednesday = 'common.wednesday';
  static const common_thursday = 'common.thursday';
  static const common_friday = 'common.friday';
  static const common_saturday = 'common.saturday';
  static const common_sunday = 'common.sunday';
  static const common_h = 'common.h';
  static const common_day = 'common.day';
  static const common_ok = 'common.ok';
  static const common_upload_picture = 'common.upload_picture';
  static const common_take_a_picture = 'common.take_a_picture';
  static const common_choose_from_lib = 'common.choose_from_lib';
  static const common_cancel = 'common.cancel';
  static const common_select = 'common.select';
  static const common_close = 'common.close';
  static const common_back = 'common.back';
  static const common_off = 'common.off';
  static const common_change_picture = 'common.change_picture';
  static const common_delete_picture = 'common.delete_picture';
  static const common_read_more = 'common.read_more';
  static const common_less = 'common.less';
  static const common_please_enter_password = 'common.please_enter_password';
  static const common_please_enter_email = 'common.please_enter_email';
  static const common_please_enter_full_name = 'common.please_enter_full_name';
  static const common_please_correct_phone_number =
      'common.please_correct_phone_number';
  static const common_please_correct_dob = 'common.please_correct_dob';
  static const common_ = 'common.';

  static const login_dont_have_an_account_sign_up =
      'login.dont_have_an_account_sign_up';
  static const login_forgot_your_password = 'login.forgot_your_password';
  static const login_password = 'login.password';
  static const login_login = 'login.login';
  static const login_user_name = 'login.user_name';
  static const login_sign_in = 'login.sign_in';
  static const login_sign_in_with_facebook = 'login.sign_in_with_facebook';
  static const login_sign_in_with_apple = 'login.sign_in_with_apple';
  static const login_sign_in_with_google = 'login.sign_in_with_google';
  static const login_please_sign_in_to_your_account =
      'login.please_sign_in_to_your_account';
  static const login_welcome = 'login.welcome';
  static const login_to = 'login.to';
  static const login_floral_punk = 'login.floral_punk';
  static const login_become_a_member = 'login.become_a_member';
  static const login_ = 'login.';

  static const splash_floral_punk = 'splash.floral_punk';
  static const splash_minimal_with_a_premium = 'splash.minimal_with_a_premium';
  static const splash_explore_more = 'splash.explore_more';
  static const splash_become_a_member = 'splash.become_a_member';
  static const splash_ = 'splash.';

  static const register_become_a_member = 'register.become_a_member';
  static const register_full_name = 'register.full_name';
  static const register_birthday = 'register.birthday';
  static const register_phone_number = 'register.phone_number';
  static const register_we_will_send_an_otp_code_to =
      'register.we_will_send_an_otp_code_to';
  static const register_confirm_otp = 'register.confirm_otp';
  static const register_resend = 'register.resend';
  static const register_resend_in = 'register.resend_in';
  static const register_ = 'register.';
}

extension StringExtension on String {
  String format(List<String> params) => _interpolate(this, params);

  String _interpolate(String string, List<String> params) {
    var result = string;
    for (var i = 1; i < params.length + 1; i++) {
      result = result.replaceAll('%$i\$', params[i - 1]);
    }

    return result;
  }
}
