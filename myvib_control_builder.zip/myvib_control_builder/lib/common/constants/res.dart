part of 'constants.dart';

const String image_path = 'assets/images';
const String gif_path = 'assets/gifs';

class Res {
  static const ic_empty = '$image_path/icon_empty.png';
  static const image_lorem = '$image_path/image_lorem.png';
  static const intro_image = '$image_path/intro_image.jpg';
  static const ic_arrow_back = '$image_path/ic_arrow_back.svg';
  static const ic_google = '$image_path/ic_google.svg';
  static const ic_facebook = '$image_path/ic_facebook.svg';
  static const ic_apple = '$image_path/ic_apple.svg';

  static String getFlagPath(String? file) => '$image_path/$file.png';
}
