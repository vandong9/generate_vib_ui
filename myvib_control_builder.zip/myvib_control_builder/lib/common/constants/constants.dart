part 'res.dart';

part 'lang.dart';
