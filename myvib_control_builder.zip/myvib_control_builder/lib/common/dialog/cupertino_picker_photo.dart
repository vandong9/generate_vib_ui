import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../constants/constants.dart';

import '../theme/theme.dart';

@immutable
class CupertinoPickerPhotoView extends StatelessWidget {
  final picker = ImagePicker();
  final Function(String path) onSelectPhoto;
  final Function()? onDelete;

  CupertinoPickerPhotoView({
    Key? key,
    required this.onSelectPhoto,
    this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CupertinoActionSheet(
        actions: <Widget>[
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              isDefaultAction: true,
              onPressed: () {
                getCameraPhoto(context);
              },
              child: Text(
                Lang.common_take_a_picture.tr(),
                style: textNormal.copyWith(
                  color: ThemeColor.blackColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              isDefaultAction: true,
              onPressed: () {
                getGalleryPhoto(context);
              },
              child: Text(
                Lang.common_choose_from_lib.tr(),
                style: textNormal.copyWith(
                  color: ThemeColor.blackColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          if (onDelete != null)
            Container(
              color: ThemeColor.whiteColor,
              child: CupertinoActionSheetAction(
                isDefaultAction: true,
                onPressed: () {
                  Navigator.pop(context);
                  onDelete!();
                },
                child: Text(
                  Lang.common_delete_picture.tr(),
                  style: textNormal.copyWith(
                    color: ThemeColor.blackColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            )
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text(
            Lang.common_cancel.tr(),
            style: textSmallxx.copyWith(color: ThemeColor.blackColor),
          ),
        ));
  }

  Future getGalleryPhoto(BuildContext context) async {
    Navigator.pop(context);
    final image =
        await picker.pickImage(maxWidth: 512, source: ImageSource.gallery);
    if (image != null) {
      onSelectPhoto(image.path);
    }
  }

  Future getCameraPhoto(BuildContext context) async {
    Navigator.pop(context);
    final image =
        await picker.pickImage(maxWidth: 512, source: ImageSource.camera);
    if (image != null) {
      onSelectPhoto(image.path);
    }
  }
}
