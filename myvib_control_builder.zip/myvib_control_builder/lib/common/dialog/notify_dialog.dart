import 'package:flutter/material.dart';

import '../../utils/navigate_util.dart';
import '../theme/theme.dart';
import '../widget/buttons/my_button.dart';
import '../widget/text/my_text_view.dart';
import 'normal_dialog_template.dart';

class NotifyDialog extends StatelessWidget {
  final String? title;
  final String? content;
  final String? textButton;
  final Widget? optionalWidget;
  final Function? onClose;

  const NotifyDialog({
    Key? key,
    this.title,
    this.content,
    this.textButton,
    this.optionalWidget,
    this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: defaultTheme(),
      child: NormalDialogTemplate.makeTemplate(
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (title?.isNotEmpty ?? false)
                      MyTextView(
                        text: title,
                        textStyle: textSmallxx.copyWith(
                            color: ThemeColor.blackFont,
                            fontWeight: FontWeight.w700,
                            fontFamily: MyFontFamily.Helvetica),
                      ),
                    const SizedBox(
                      height: sizeNormalxx,
                    ),
                    MyTextView(
                      text: content,
                      textStyle: textSmallxxx.copyWith(
                          color: ThemeColor.blackFont,
                          fontWeight: FontWeight.w400,
                          fontFamily: MyFontFamily.Helvetica),
                    ),
                    const SizedBox(
                      height: sizeNormal,
                    ),
                    optionalWidget ?? const SizedBox(),
                    MyButton(
                      text: textButton ?? 'OK',
                      paddingHorizontal: sizeLargexx,
                      height: sizeLarge,
                      isFillParent: false,
                      onTap: () {
                        NavigateUtil.pop(context);
                      },
                      textStyle: textSmallxxx.copyWith(
                          color: const Color(0xff383838),
                          fontWeight: FontWeight.w700,
                          fontFamily: MyFontFamily.Helvetica),
                    ),
                  ],
                ),
              ),
            ],
          ),
          border: Border.all(
              width: 1, //
              color: const Color(0xff737272) //          <--- border width here
              ),
          insetPadding: const EdgeInsets.only(
            bottom: sizeSmallx,
            right: sizeSmallx,
            left: sizeSmallx,
            top: sizeSmallx,
          ),
          backgroundColor: ThemeColor.whiteColor,
          insetMargin: const EdgeInsets.all(sizeNormal),
          positionDialog: PositionDialog.center),
    );
  }
}
