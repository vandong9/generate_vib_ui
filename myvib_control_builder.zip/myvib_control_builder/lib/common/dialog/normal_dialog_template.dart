import 'package:flutter/material.dart';
import '../theme/theme.dart';

@immutable
class NormalDialogTemplate {
  static Widget makeTemplate(
    Widget child, {
    PositionDialog? positionDialog,
    Color? backgroundColor,
    EdgeInsets? insetPadding,
    EdgeInsets? insetMargin,
    BoxBorder? border,
  }) {
    return Stack(
      children: <Widget>[
        Positioned.fill(
          child: Align(
            alignment: _getPositionDialog(positionDialog),
            child: Container(
              margin: insetMargin,
              padding: insetPadding ?? const EdgeInsets.all(sizeNormal),
              decoration: BoxDecoration(
                color: backgroundColor,
                shape: BoxShape.rectangle,
                border: border,
                borderRadius: _getBorderRadius(positionDialog),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: sizeSmall,
                    offset: Offset(0.0, sizeSmall),
                  ),
                ],
              ),
              child: child,
            ),
          ),
        ),
      ],
    );
  }

  static BorderRadius _getBorderRadius(PositionDialog? positionDialog) {
    switch (positionDialog) {
      case PositionDialog.topCenter:
        return const BorderRadius.only(
            bottomLeft: Radius.circular(sizeSmallxxx),
            bottomRight: Radius.circular(sizeSmallxxx));
      case PositionDialog.center:
        return BorderRadius.circular(sizeSmallxxx);
      case PositionDialog.bottomCenter:
        return const BorderRadius.only(
            topLeft: Radius.circular(sizeSmallxxx),
            topRight: Radius.circular(sizeSmallxxx));
      default:
        return BorderRadius.circular(sizeSmallxxx);
    }
  }

  static Alignment _getPositionDialog(PositionDialog? positionDialog) {
    switch (positionDialog) {
      case PositionDialog.topCenter:
        return Alignment.topCenter;
      case PositionDialog.center:
        return Alignment.center;
      case PositionDialog.bottomCenter:
        return Alignment.bottomCenter;
      default:
        return Alignment.center;
    }
  }
}

enum PositionDialog { topCenter, center, bottomCenter }
