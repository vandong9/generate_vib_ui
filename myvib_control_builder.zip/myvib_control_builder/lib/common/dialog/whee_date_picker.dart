import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../utils/navigate_util.dart';
import '../constants/constants.dart';
import '../theme/theme.dart';
import '../widget/buttons/my_button.dart';

class WheelDatePicker extends StatefulWidget {
  final DateTime currentDate;
  final CupertinoDatePickerMode cupertinoDatePickerMode;
  final bool canSelectPast;
  final DatePickerDateOrder dateOrder;

  const WheelDatePicker({
    Key? key,
    required this.currentDate,
    this.dateOrder = DatePickerDateOrder.ymd,
    this.canSelectPast = false,
    required this.cupertinoDatePickerMode,
  }) : super(key: key);

  @override
  _WheelDatePickerState createState() => _WheelDatePickerState();
}

class _WheelDatePickerState extends State<WheelDatePicker> {
  late ValueNotifier<int> yearUpdate;
  late CupertinoDatePickerMode cupertinoDatePickerMode;
  DateTime currentDate = DateTime.now();
  DateTime minimumDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    cupertinoDatePickerMode = widget.cupertinoDatePickerMode;
    currentDate = widget.currentDate.isBefore(currentDate)
        ? currentDate
        : widget.currentDate;
    currentDate = DateTime(
      currentDate.year,
      currentDate.month,
      currentDate.day,
      currentDate.hour,
      calMinus(currentDate.minute),
    );
    yearUpdate = ValueNotifier(currentDate.year);
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Wrap(
        children: [
          Container(
            color: Colors.white,
            child: Column(
              children: [
                const SizedBox(
                  height: sizeNormal,
                ),
                if (cupertinoDatePickerMode ==
                    CupertinoDatePickerMode.dateAndTime)
                  ValueListenableBuilder<int>(
                      valueListenable: yearUpdate,
                      builder: (context, value, snapshot) {
                        return Text(
                          value.toString(),
                          style: textLarge.copyWith(
                            color: ThemeColor.blackFont,
                            fontWeight: FontWeight.w700,
                          ),
                        );
                      }),
                Container(
                  height: sizeImageLargexx,
                  child: CupertinoDatePicker(
                    mode: cupertinoDatePickerMode,
                    dateOrder: widget.dateOrder,
                    minimumDate: widget.canSelectPast
                        ? null
                        : DateTime(
                            minimumDate.year,
                            minimumDate.month,
                            minimumDate.day,
                            0,
                            0,
                          ),
                    initialDateTime: currentDate,
                    onDateTimeChanged: (DateTime newDateTime) {
                      if (newDateTime.year != yearUpdate.value) {
                        yearUpdate.value = newDateTime.year;
                      }
                      currentDate = newDateTime;
                    },
                    use24hFormat: false,
                    minuteInterval: 15,
                  ),
                ),
                MyButton(
                  text: Lang.common_select.tr(),
                  paddingHorizontal: sizeLargexx,
                  height: sizeLarge,
                  isFillParent: false,
                  onTap: () {
                    NavigateUtil.pop(context, argument: currentDate);
                  },
                  textStyle: textSmallxxx.copyWith(
                    color: const Color(0xff383838),
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(
                  height: sizeSmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  int calMinus(int mins) {
    return (mins ~/ 15) * 15 + (mins % 15 == 0 ? 0 : 15);
  }
}
