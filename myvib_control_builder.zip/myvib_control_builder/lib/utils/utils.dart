import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:crypto/crypto.dart';

import '../common/di/injection/injector.dart';

class Utils {
  static final RegExp _emailRegExp = RegExp(
    r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+",
  );

  static bool isValidEmail(String email) => _emailRegExp.hasMatch(email);

  static bool isValidPassword(String password) => password.isNotEmpty;

//      _passwordRegExp.hasMatch(password);

  static bool validateUserName(String value) {
    if (value.isEmpty) {
      return false;
    }
    final nameExp =
        // ignore: valid_regexps
        RegExp(r'^(?=[a-zA-Z0-9._]{4,64}$)(??.*[_.]{2})[^_.].*[^_.]$');
    if (!nameExp.hasMatch(value)) {
      return false;
    }

    return true;
  }

  static bool isPasswordCompliant(String password, [int minLength = 6]) {
    if (password.isEmpty) {
      return false;
    }
    // final hasUppercase = password.contains(RegExp(r'[A-Z]'));
    // final hasDigits = password.contains(RegExp(r'[0-9]'));
    // final hasSpecialCharacters = !password.contains(RegExp(r'[\s]'));
    final hasMinLength = password.length >= minLength;
    return hasMinLength;
  }

  static bool isPasswordUppercase(String password) {
    if (password.isEmpty) {
      return false;
    }
    final hasUppercase = password.contains(RegExp(r'[A-Z]'));
    return hasUppercase;
  }

  static bool isPasswordDigits(String password) {
    if (password.isEmpty) {
      return false;
    }
    final hasDigits = password.contains(RegExp(r'[0-9]'));
    return hasDigits;
  }

  static bool isPasswordSpecialCharacters(String password) {
    if (password.isEmpty) {
      return false;
    }

    final hasSpecialCharacters = !password.contains(RegExp(r'[\s]'));
    return hasSpecialCharacters;
  }

  static bool isPasswordMinLength(String password, [int minLength = 8]) {
    if (password.isEmpty) {
      return false;
    }

    final hasMinLength = password.length > minLength;
    return hasMinLength;
  }

  //Encrypt data by Fernet
  static String encData(String? str) {
    // final key = Key.fromUtf8(ENC_KEY);
    //
    // final b64key = Key.fromUtf8(base64Url.encode(key.bytes));
    // // if you need to use the ttl feature, you'll need to use APIs in the algorithm itself
    // final fernet = Fernet(b64key);
    // final encrypter = Encrypter(fernet);
    // final encrypted = encrypter.encrypt(str!);
    return str ?? '';
  }

  //Decrypt data by Fernet
  static String decData(String str) {
    // final key = Key.fromUtf8(ENC_KEY);
    //
    // final b64key = Key.fromUtf8(base64Url.encode(key.bytes));
    // // if you need to use the ttl feature, you'll need to use APIs in the algorithm itself
    // final fernet = Fernet(b64key);
    // final encrypter = Encrypter(fernet);
    // final decrypted = encrypter.decrypt(Encrypted.from64(str));
    return str;
  }

  static String generateMd5(String input) {
    return md5.convert(utf8.encode(input)).toString();
  }

  static Future<String> getDeviceDetails() async {
    // ignore: prefer_typing_uninitialized_variables

    return 'identifier';
  }

  static Future<String> getOsVersion() async {
    // late String os;
    // final deviceInfoPlugin = DeviceInfoPlugin();
    // try {
    //   if (Platform.isAndroid) {
    //     final build = await deviceInfoPlugin.androidInfo;
    //     os = build.version.release; //UUID for Android
    //   } else if (Platform.isIOS) {
    //     final data = await deviceInfoPlugin.iosInfo;
    //     os = data.systemName; //UUID for iOS
    //   }
    // } on PlatformException {
    //   print('Failed to get platform version');
    // }

    return 'os';
  }

  // static Future<String> getDeviceToken() async {
  //   final firebaseWrapper = sl<FirebaseWrapper>();
  //   return firebaseWrapper.tokenLocal!;
  // }

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) {
      buffer.write('ff');
    }
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
