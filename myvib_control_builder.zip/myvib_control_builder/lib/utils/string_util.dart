import 'dart:io';
import 'dart:math';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:encrypt/encrypt.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:uuid/uuid.dart';
import '../data/model/user_info.dart';

const uuid = Uuid();

String format(String template, List<Object> arguments) {
  var result = '';
  var argumentsIndex = 0;
  for (var index = 0; index < template.length; index++) {
    if (template.codeUnitAt(index) == 37 /* ascii '%' */) {
      result += arguments[argumentsIndex++].toString();
    } else {
      result += template.substring(index, index + 1);
    }
  }
  return result;
}

String? validateMobile(String value) {
  if (value.isEmpty) {
    return null;
  }
  const pattern = r'(^(?:[+0]9)?[0-9]{9,13}$)';
  final regExp = RegExp(pattern);
  if (value.isEmpty) {
    return 'Please enter mobile number';
  } else if (!regExp.hasMatch(value)) {
    return 'Please enter valid mobile number';
  }
  return null;
}

String validatePassword(String value) {
  if (value.isEmpty) {
    return 'Please choose a password.';
  }
  return '';
}

String validateRePassword(String pass, String repass) {
  if (repass != pass) {
    return 'Repassword not match with Password.';
  }
  return '';
}

String validateCodePassword(String code) {
  if (code.isEmpty) {
    return 'Code is required.';
  }
  return '';
}

Future<String> getAppVersionAndDate() async {
  final packageInfo = await PackageInfo.fromPlatform();
  final version = packageInfo.version;
  const date = '20220207';
  return 'v$version@$date';
}

Future<String> getAppVersion() async {
  final packageInfo = await PackageInfo.fromPlatform();
  final version = packageInfo.version;
  return version;
}

Future<String> getDeviceId() async {
  final deviceInfo = DeviceInfoPlugin();
  if (Platform.isIOS) {
    // import 'dart:io'
    final iosDeviceInfo = await deviceInfo.iosInfo;
    return iosDeviceInfo.identifierForVendor ?? 'uuidiOS'; // unique ID on iOS
  } else {
    final androidDeviceInfo = await deviceInfo.androidInfo;
    return androidDeviceInfo.id ?? 'uuidAndroid'; // unique ID on Android
  }
}

String getPlatform() {
  return Platform.isAndroid ? 'android' : 'ios';
}

String encryptData({
  required String data,
}) {
  final key = Key.fromBase64('DAHCSQIYXEMaTIFQ+snzlOHnj5gL0rnOFob09WHBR3E=');

  final iv = IV.fromBase64('4ITzjNJlxAYWDTfK+9gIig==');

  final encrypter = Encrypter(AES(key, mode: AESMode.cbc, padding: 'PKCS7'));

  return encrypter.encrypt(data, iv: iv).base64;
}

String decryptData({
  required String data,
}) {
  final key = Key.fromBase64('DAHCSQIYXEMaTIFQ+snzlOHnj5gL0rnOFob09WHBR3E=');
  print(key.base64);
  final iv = IV.fromBase64('4ITzjNJlxAYWDTfK+9gIig==');

  final encrypter = Encrypter(AES(key, mode: AESMode.cbc, padding: 'PKCS7'));

  return encrypter.decrypt64(data, iv: iv);
}

String genUUID() {
  return uuid.v4();
}
