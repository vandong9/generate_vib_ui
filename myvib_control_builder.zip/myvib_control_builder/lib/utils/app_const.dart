import 'dart:ui';

import '../common/constants/constants.dart';

const DEFAULT_PAGE_INDEX = 1;
const ENC_KEY = 'fldisf32423423hr3n2kj3r#@32432f3';
const IAP_K = '8f08c41546ffa44a39c593a430239e8';
const DEFAULT_TIMEZONE = 'Etc/UTC';
const DEFAULT_CURRENCY= 'USD';

const PRIVACY_POLICY =
    'https://salonmanager.com/legal/headless/privacy-policy.html';
const TERM_OF_USE = 'https://salonmanager.com/legal/headless/terms-of-use.html';

const List<Color> baseColorList = [
  Color(0xffec6a64),
  Color(0xff57c1d2),
  Color(0xfff09835),
  Color(0xff7cc689),
  Color(0xff8882f8),
  Color(0xff2a54a7),
  Color(0xff898a96),
  Color(0xff5eadf8)
];

const Map<String, int> indexDayOfWeek = {
  'Monday': 0,
  'Tuesday': 1,
  'Wednesday': 2,
  'Thursday': 3,
  'Friday': 4,
  'Saturday': 5,
  'Sunday': 6,
};

const Map<int, String> mapDayOfWeek = {
  0: Lang.common_monday,
  1: Lang.common_tuesday,
  2: Lang.common_wednesday,
  3: Lang.common_thursday,
  4: Lang.common_friday,
  5: Lang.common_saturday,
  6: Lang.common_sunday,
};

const maxLenUserName = 64;
const maxLenFullName = 128;
const maxLenPassword = 128;
const maxLenPhoneNumber = 13;
const maxLenEmail = 320;
const MIN_STEP = 15;
const MIN_STEP_FIVE = 5;
const MIN_DURATION = 15;
const TOTAL_DAY_WEEK_VIEW = 7;

