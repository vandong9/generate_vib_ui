import 'package:intl/intl.dart';

String formatPriceNumber(int? number, {String formatUnit = 'vn'}) {
  final formatter = NumberFormat('###,###');
  return formatter.format(number) + (formatUnit == 'vn' ? ' VND' : ' \$');
}

String formatPriceNumberNonUnit(
  double number, {
  String? symbol = '\$',
  int div = 100,
  bool useDashForEmpty = false,
}) {
  if (number == 0 && useDashForEmpty) {
    return '—';
  }
  final value = number / div;
  final formatter = NumberFormat('#,##0.00', 'en_US');
  symbol = symbol ?? '\$';
  return symbol + formatter.format(value);
}

String formatStringToPer(
  double number, {
  bool useDashForEmpty = false,
  bool isComma = true,
}) {
  if (number == 0 && useDashForEmpty) {
    return '—';
  }
  final value = number / 100;
  final formatter = isComma
      ? NumberFormat('#,##0.00', 'en_US')
      : NumberFormat('#.##0.00', 'en_US');
  return formatter.format(value) + '%';
}

String formatPriceDoubleNumberNonUnit(
  double number, {
  String symbol = '\$',
  bool useDashForEmpty = false,
}) {
  if (number == 0 && useDashForEmpty) {
    return '—';
  }
  final value = number / 100;
  final formatter = NumberFormat('#,##0.00', 'en_US');
  return symbol + formatter.format(value);
}
