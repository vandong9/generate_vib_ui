import 'package:easy_localization/easy_localization.dart' as localize;
import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../common/constants/constants.dart';
import '../common/dialog/cupertino_picker_photo.dart';
import '../common/theme/theme.dart';
import '../common/widget/text/my_text_view.dart';

class UIUtil {
  static const ARR_BG_AVATAR = [
    Colors.pinkAccent,
    Colors.orangeAccent,
    Colors.blueAccent,
    Colors.redAccent,
    Colors.amberAccent,
    Colors.cyan,
    Colors.deepOrange,
  ];

  static ImageProvider makeImageDecoration(
    String url, {
    String? placeHolder,
    BoxFit? fit,
  }) {
    url = (url.isEmpty) ? Res.image_lorem : url;
    ImageProvider imgProvider;
    if (url.contains('http') || url.contains('https')) {
      imgProvider = ExtendedImage.network(
        url,
        enableLoadState: true,
        cache: true,
        fit: fit,
        handleLoadingProgress: true,
        loadStateChanged: (ExtendedImageState state) {
          switch (state.extendedImageLoadState) {
            case LoadState.loading:
              return makeCircleImageWidget(placeHolder, size: 40);
            case LoadState.failed:
              return makeCircleImageWidget(placeHolder, size: 40);
            case LoadState.completed:
              return ExtendedRawImage(
                image: state.extendedImageInfo?.image,
              );
            default:
              return makeCircleImageWidget(placeHolder, size: 40);
          }
        },
      ).image;
    } else {
      imgProvider = AssetImage(url);
    }
    return imgProvider;
  }

  static Widget makeImageWidget(
    String? url, {
    double? width,
    double? height,
    String? placeHolder,
    bool? useOldImageOnUrlChange,
    Alignment? alignment,
    Size? size,
    BoxFit? boxFit,
    Color? color,
    BlendMode? blendMode,
    FilterQuality? filterQuality,
  }) {
    placeHolder = placeHolder ?? Res.image_lorem;
    url = url?.replaceAll('\\', '//');
    if (size != null) {
      width = size.width;
      height = size.height;
    }
    filterQuality = filterQuality ?? FilterQuality.low;

    url = (url == null || url.isEmpty) ? '' : url;
    Widget imgWidget;
    if (url.contains('http') || url.contains('https')) {
      imgWidget = ExtendedImage.network(
        url,
        width: width,
        height: height,
        alignment: alignment ?? Alignment.center,
        enableLoadState: true,
        colorBlendMode: blendMode,
        cache: true,
        handleLoadingProgress: true,
        loadStateChanged: (ExtendedImageState state) {
          switch (state.extendedImageLoadState) {
            case LoadState.loading:
              return makeImageWidget(
                placeHolder,
                boxFit: boxFit,
              );
            case LoadState.failed:
              return makeImageWidget(
                placeHolder,
                boxFit: boxFit,
              );
            case LoadState.completed:
              return ExtendedRawImage(
                fit: boxFit,
                width: width,
                alignment: alignment ?? Alignment.center,
                height: height,
                colorBlendMode: blendMode,
                image: state.extendedImageInfo?.image,
              );
            default:
              return makeImageWidget(
                placeHolder,
                boxFit: boxFit,
              );
          }
        },
        filterQuality: filterQuality,
        fit: boxFit,
      );
    } else if (url.contains('assets')) {
      imgWidget = Image(
        image: AssetImage(url),
        width: width,
        colorBlendMode: blendMode,
        alignment: alignment ?? Alignment.center,
        color: color,
        height: height,
        fit: boxFit,
      );
    } else {
      imgWidget = makeImageWidget(
        placeHolder,
        alignment: alignment ?? Alignment.center,
        boxFit: boxFit,
      );
    }
    return imgWidget;
  }

  static Widget makeCircleImageWidget(
    String? url, {
    double? size,
    Color color = Colors.amber,
    Color borderColor = const Color(0xffF5D484),
    bool shadowOn = false,
    String? initialName,
    TextStyle? textStyle,
  }) {
    url = url?.replaceAll('\\', '//');
    if ((url == null || url.isEmpty) &&
        initialName != null &&
        initialName.isNotEmpty) {
      textStyle = textStyle ?? textNormal;
      final listWords = initialName.trim().split(' ');
      final lastWord = listWords[listWords.length - 1];
      final firstCharacter = lastWord[0].toUpperCase();

      var sumCharsCode = 0;
      lastWord.codeUnits.forEach((e) => sumCharsCode += e);
      final pickRandomBgColor = sumCharsCode % ARR_BG_AVATAR.length;
      return Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          boxShadow: shadowOn
              ? [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    spreadRadius: size ?? 0 * 0.08,
                    blurRadius: size ?? 0 * 0.04,
                    offset: const Offset(0, 2), // changes position of shadow
                  ),
                ]
              : null,
          shape: BoxShape.circle,
          color: ARR_BG_AVATAR[pickRandomBgColor],
        ),
        child: MyTextView(
          text: firstCharacter,
          textStyle: textStyle.copyWith(color: Colors.white),
        ),
      );
    }
    return ClipOval(
      child: Container(
        child: makeImageWidget(
          url,
          boxFit: BoxFit.cover,
          width: size,
          height: size,
        ),
      ),
    );
  }

  static Future<dynamic> showDialogOrigin({
    required Widget child,
    required BuildContext context,
    bool barrierDismissible = true,
    Color? barrierColor,
  }) {
    barrierColor ??= Colors.black.withOpacity(0.5);
    return showDialog(
        barrierColor: barrierColor,
        barrierDismissible: barrierDismissible,
        useSafeArea: false,
        context: context,
        // ignore: missing_return
        builder: (_) => child);
  }

  static Future<dynamic> showDialogQuestion({
    String? title,
    required String message,
    required Function actionYes,
    required BuildContext context,
  }) {
    return showCupertinoModalPopup<dynamic>(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        actions: <Widget>[
          Container(
            color: ThemeColor.whiteColor,
            padding: const EdgeInsets.all(
              sizeSmall,
            ),
            alignment: Alignment.center,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (title?.isNotEmpty ?? false)
                  Text(
                    title ?? '',
                    style: textNormalxxx.copyWith(
                      color: ThemeColor.blackColor,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                const SizedBox(
                  height: sizeNormal,
                ),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: textSmallxxx.copyWith(
                    color: ThemeColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
                actionYes();
              },
              child: Text(Lang.common_yes.tr()),
            ),
          ),
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(Lang.common_no.tr()),
            ),
          )
        ],
      ),
    );
  }

  static Future<dynamic> showDialogQuestionDeletePhoto({
    required String title,
    required String message,
    required Function actionYes,
    required BuildContext context,
    required String imagePath,
  }) {
    return showCupertinoModalPopup<dynamic>(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        actions: <Widget>[
          Container(
            color: ThemeColor.whiteColor,
            padding: const EdgeInsets.all(
              sizeSmall,
            ),
            child: Column(
              children: [
                Text(
                  title,
                  style: textNormalxxx.copyWith(
                    color: ThemeColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(
                  height: sizeNormal,
                ),
                Text(
                  message,
                  style: textSmallxxx.copyWith(
                    color: ThemeColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(
                  height: sizeSmall,
                ),
                ClipRRect(
                  borderRadius: const BorderRadius.all(
                    Radius.circular(sizeSmall),
                  ),
                  child: SizedBox(
                    height: sizeImageLarge,
                    child: makeImageWidget(
                      imagePath,
                      boxFit: BoxFit.cover,
                    ),
                  ),
                ),
                const SizedBox(
                  height: sizeSmall,
                ),
              ],
            ),
          ),
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
                actionYes();
              },
              child: Text(Lang.common_yes.tr()),
            ),
          ),
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(Lang.common_no.tr()),
            ),
          )
        ],
      ),
    );
  }

  static Future<dynamic> showDialogScheduleQuestion({
    required String title,
    required String messageStart,
    required String messageBold,
    required String messageEnd,
    required Function actionYes,
    required BuildContext context,
  }) {
    return showCupertinoModalPopup<dynamic>(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        actions: <Widget>[
          Container(
            color: ThemeColor.whiteColor,
            padding: const EdgeInsets.all(
              sizeSmall,
            ),
            child: Column(
              children: [
                Text(
                  title,
                  style: textNormalxxx.copyWith(
                    color: ThemeColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(
                  height: sizeSmallxx,
                ),
                RichText(
                  text: TextSpan(
                    style: DefaultTextStyle.of(context).style,
                    children: <TextSpan>[
                      TextSpan(
                          text: messageStart,
                          style: textNormal.copyWith(
                            fontWeight: FontWeight.w400,
                            color: ThemeColor.blackColor,
                          )),
                      TextSpan(
                          text: messageBold,
                          style: textNormal.copyWith(
                            fontWeight: FontWeight.bold,
                            color: ThemeColor.blackColor,
                          )),
                      TextSpan(
                          text: messageEnd,
                          style: textNormal.copyWith(
                            fontWeight: FontWeight.w400,
                            color: ThemeColor.blackColor,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
                actionYes();
              },
              child: Text(Lang.common_yes.tr()),
            ),
          ),
          Container(
            color: ThemeColor.whiteColor,
            child: CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(Lang.common_no.tr()),
            ),
          )
        ],
      ),
    );
  }

  static Future<dynamic> showDialogAnimation({
    required Widget child,
    required BuildContext context,
    bool isSlideDown = true,
    Color? barrierColor,
  }) {
    barrierColor ??= Colors.black.withOpacity(0.5);
    return showGeneralDialog(
        barrierColor: barrierColor,
        transitionBuilder: (context, a1, a2, widget) {
          var valueSlide = -1;
          if (isSlideDown) {
            valueSlide = 1;
          }
          final curvedValue = Curves.linearToEaseOut.transform(a1.value) - 1;

          return Transform(
            transform: Matrix4.translationValues(
                0.0, curvedValue * valueSlide * 300, 0.0),
            child: Opacity(
              opacity: a1.value,
              child: child,
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
        barrierDismissible: true,
        barrierLabel: '',
        context: context,
        // ignore: missing_return
        pageBuilder: (context, animation1, animation2) {
          return const SizedBox();
        });
  }

  static void showToast(
    String? mess, {
    Toast toastLength = Toast.LENGTH_LONG,
    ToastGravity gravity = ToastGravity.BOTTOM,
    Color backgroundColor = Colors.grey,
    Color textColor = Colors.white,
    double fontSize = sizeSmallxxx,
  }) {
    Fluttertoast.showToast(
      msg: mess ?? '',
      toastLength: toastLength,
      gravity: gravity,
      timeInSecForIosWeb: 1,
      backgroundColor: backgroundColor,
      textColor: textColor,
      fontSize: fontSize,
    );
  }

  static void takeImage({
    required BuildContext context,
    Function()? onDelete,
    required Function(String) onSelectedPhoto,
  }) {
    showCupertinoModalPopup(
        context: context,
        builder: (context) => CupertinoPickerPhotoView(
              onSelectPhoto: onSelectedPhoto,
              onDelete: onDelete,
            ));
  }

  static Size getTextSize({
    required String text,
    required TextStyle style,
  }) {
    final textPainter = TextPainter(
      text: TextSpan(text: text, style: style),
      maxLines: 1,
      textDirection: TextDirection.ltr,
    )..layout(minWidth: 0, maxWidth: double.infinity);
    return textPainter.size;
  }

  static BoxDecoration getFirstDayBoxDecorationByLang(BuildContext context) {
    return const BoxDecoration(
        color: Color(0xff419C9B),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(50.0),
          bottomLeft: Radius.circular(50.0),
        ));
  }

  static BoxDecoration getLastDayBoxDecorationByLang(BuildContext context) {
    return const BoxDecoration(
        color: Color(0xff419C9B),
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(50.0),
          bottomRight: Radius.circular(50.0),
        ));
  }
}
