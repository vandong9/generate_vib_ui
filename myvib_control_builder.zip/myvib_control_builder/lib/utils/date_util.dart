import 'package:intl/intl.dart';

// ignore: unused_import
import 'package:jiffy/jiffy.dart';
import 'package:timezone/timezone.dart' as tz;

// ignore: directives_ordering, unused_import
import 'package:timezone/data/latest_all.dart' as tz;

import 'app_const.dart';

class DateUtil {
  // America/Los_Angeles

  static const DATE_FORMAT_VERSION = 'ddMMyyyy';

  static const DATE_FORMAT_EEE = 'EEE';
  static const DATE_FORMAT_DDMMYYYY = 'dd/MM/yyyy';
  static const DATE_FORMAT_MMDDYYYY = 'MM/dd/yyyy';
  static const DATE_FORMAT_YYYYMMDD = 'yyyy-MM-dd';
  static const DATE_FORMAT_MMMM_D_YYYY = 'MMMM d, yyyy';
  static const DATE_FORMAT_HOLIDAY = 'yyyy-MM-dd HH:mm:ss';
  static const DATE_FORMAT_EEE_MMM_D_YYYY = 'EEE, MMM d, yyyy';
  static const DATE_FORMAT_EEE_MMM_D_YYYY_NO_COMMAND = 'EEE MMM d yyyy';
  static const DATE_FORMAT_EEE_MMM_D_YYYY_HH_MM = 'EEE, MMM d, yyyy @ h:mm aa';
  static const DATE_FORMAT_MMM_YYYY = 'MMM yyyy';
  static const DATE_FORMAT_YYYY = 'yyyy';
  static const DATE_FORMAT_EEEE = 'EEEE';
  static const DATE_FORMAT_HHMMAA = 'h:mm aa';
  static const DATE_FORMAT_HHMM = 'HH:mm';

  static const DATE_FORMAT_MMM_d = 'MMM d';
  static const DATE_FORMAT_d = 'd';
  static const DATE_FORMAT_DDMMMYYYY = 'dd MMM ,yyyy';
  static const DATE_FORMAT_MMM = 'MMM';
  static const DATE_FORMAT_YYYYMMDD_HHMM = 'yyyy-MM-dd HH:mm';
  static const DATE_FORMAT_EMMDDYYY = 'EEEE, MMMM do, yyyy';
  static const DATE_FORMAT_DD = 'dd';
  static const FORMAT_DATE_TIME_CS = 'dd/MM/yyyy HH:mm:ss';

  static DateTime currentDate() {
    return DateTime.now();
  }

  static bool isBeforeCurrentDate(DateTime dateTime) {
    final currentDate = DateTime.now();
    if (dateTime.isAfter(currentDate)) {
      return false;
    }
    return !(dateTime.year == currentDate.year &&
        dateTime.month == currentDate.month &&
        dateTime.day == currentDate.day);
  }

  static bool isSameCurrentDate(DateTime dateTime) {
    final currentDate = DateTime.now();

    return dateTime.year == currentDate.year &&
        dateTime.month == currentDate.month &&
        dateTime.day == currentDate.day;
  }

  static String getFirstDayOfWeekString(DateTime dateTime) {
    final s = DateFormat(DATE_FORMAT_YYYYMMDD, 'en-US');
    var firstDayOfWeek = dateTime;
    if (dateTime.weekday != 7) {
      firstDayOfWeek = dateTime.subtract(Duration(days: dateTime.weekday + 1));
    }

    return s.format(firstDayOfWeek);
  }

  static DateTime resetDay(DateTime dateTime) {
    return DateTime(dateTime.year, dateTime.month, dateTime.day, 0, 0, 0, 0, 0);
  }

  static DateTime getFirstDayOfWeek(
    DateTime dateTime,
  ) {
    ///Sunday is firstDay of week
    var firstDayOfWeek = dateTime;

    if (dateTime.weekday != 7) {
      firstDayOfWeek = dateTime.subtract(Duration(days: dateTime.weekday + 1));
    }

    return DateTime(firstDayOfWeek.year, firstDayOfWeek.month,
        firstDayOfWeek.day, 0, 0, 0, 0, 0);
  }

  static DateTime getFromDay(
    DateTime dateTime,
  ) {
    ///Sunday is firstDay of week
    final firstDayOfWeek = dateTime;

    return DateTime(
      firstDayOfWeek.year,
      firstDayOfWeek.month,
      firstDayOfWeek.day,
      firstDayOfWeek.hour,
      firstDayOfWeek.minute,
      firstDayOfWeek.second,
      firstDayOfWeek.millisecond,
      0,
    );
  }

  static DateTime convertTimeStampToDateTime(int timeStamp) {
    return DateTime.fromMillisecondsSinceEpoch(timeStamp);
  }

  static String convertTimeStampToTime(
    int timeStamp, {
    String? format = DATE_FORMAT_HHMMAA,
  }) {
    final s = DateFormat(format, 'en-US');
    final dateTime =
        DateTime.fromMillisecondsSinceEpoch(timeStamp, isUtc: false);
    return s.format(dateTime);
  }

  static int dayOfYear(DateTime date) {
    return date.difference(DateTime(date.year, 1, 1)).inDays;
  }

  static String convertTimeStampToDateTimeString(
    int timeStamp, {
    String format = DATE_FORMAT_MMM_d,
    bool needTimeZone = true,
  }) {
    final s = DateFormat(format, 'en-US');
    final dateTime =
        DateTime.fromMillisecondsSinceEpoch(timeStamp, isUtc: false);

    if (needTimeZone) {
      return s.format(dateTime);
    }
    return s.format(dateTime);
  }

  static String convertTodayDateTimeToString({
    String format = DATE_FORMAT_MMM_d,
  }) {
    final s = DateFormat(format, 'en-US');
    final dateTime = DateTime.fromMillisecondsSinceEpoch(
        DateTime.now().millisecondsSinceEpoch,
        isUtc: false);
    return s.format(dateTime);
  }

  static DateTime convertStringToDate(String date,
      {String formatData = "yyyy-MM-dd'T'HH:mm:ss.SSS"}) {
    final s = DateFormat(formatData, 'en-US');
    return s.parse(date);
  }

  static String dateFormatEEEEddMM(DateTime date) {
    final s = DateFormat('EEEE dd MMM');
    return s.format(date);
  }

  static String dateFormatYYYYMMDD(DateTime? date) {
    if (date == null) {
      return '';
    }
    final s = DateFormat(DATE_FORMAT_YYYYMMDD);
    return s.format(date);
  }

  static int getTimeStampByTime(String time) {
    final s = DateFormat(DATE_FORMAT_YYYYMMDD);
    var date = s.format(DateTime.now());
    date = date + ' ' + time;
    final df = DateFormat(DATE_FORMAT_YYYYMMDD_HHMM, 'en-US');
    return df.parse(date).millisecondsSinceEpoch;
  }

  static String dateFormatDDMMYYYY(DateTime? date) {
    if (date == null) {
      return '';
    }
    final s = DateFormat(DATE_FORMAT_DDMMYYYY);
    return s.format(date);
  }

  static bool compareDate(DateTime? dateA, DateTime? dateB) {
    if (dateA?.day == dateB?.day &&
        dateA?.month == dateB?.month &&
        dateA?.year == dateB?.year) {
      return true;
    }
    return false;
  }
}
